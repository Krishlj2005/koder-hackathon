import { FC } from 'react';
import AppLayout from '@/components/layout/AppLayout';

const Projects: FC = () => {
  return (
    <AppLayout title="Projects">
      <div className="bg-white shadow-sm rounded-lg p-8 text-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="w-12 h-12 mx-auto text-gray-300 mb-4"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
          <path d="M9 14.25V9.75M15 14.25V9.75M12 14.25V9.75" />
          <path d="M10 6h4" />
        </svg>
        <h2 className="text-xl font-medium text-gray-700 mb-2">Projects Coming Soon</h2>
        <p className="text-gray-500 max-w-md mx-auto">
          This feature is under development. Soon you'll be able to organize your tests into projects
          and collaborate with your team.
        </p>
      </div>
    </AppLayout>
  );
};

export default Projects;