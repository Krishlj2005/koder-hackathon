import { FC } from 'react';
import AppLayout from '@/components/layout/AppLayout';

const History: FC = () => {
  return (
    <AppLayout title="Test History">
      <div className="bg-white shadow-sm rounded-lg p-8 text-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="w-12 h-12 mx-auto text-gray-300 mb-4"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <polyline points="12 6 12 12 16 14" />
        </svg>
        <h2 className="text-xl font-medium text-gray-700 mb-2">Test History Coming Soon</h2>
        <p className="text-gray-500 max-w-md mx-auto">
          We're building a comprehensive test history view that will allow you to track changes 
          over time and compare test results. Check back soon!
        </p>
      </div>
    </AppLayout>
  );
};

export default History;