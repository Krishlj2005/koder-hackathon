import { FC, useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import AppLayout from '@/components/layout/AppLayout';
import TestCreationCard from '@/components/dashboard/TestCreationCard';
import TestProgressCard from '@/components/dashboard/TestProgressCard';
import TestResultCard from '@/components/dashboard/TestResultCard';
import TestDetailsModal from '@/components/dashboard/TestDetailsModalNew';
import TestAutomationConfig from '@/components/dashboard/TestAutomationConfig';
import TestReportingPanel from '@/components/dashboard/TestReportingPanel';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Test } from '@shared/schema';

const Dashboard: FC = () => {
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [activeDashboardTab, setActiveDashboardTab] = useState("main");
  const [selectedTestForAutomation, setSelectedTestForAutomation] = useState<Test | null>(null);
  const [selectedTestForReporting, setSelectedTestForReporting] = useState<Test | null>(null);
  
  // Fetch all tests
  const { data: tests = [], refetch: refetchTests } = useQuery<Test[]>({
    queryKey: ['/api/tests'],
  });
  
  // Split tests by status
  const activeTests = tests.filter(test => test.status === 'in-progress');
  const completedTests = tests.filter(test => test.status === 'completed');
  
  // Handle test creation
  const handleTestCreated = () => {
    refetchTests();
  };
  
  // Handle viewing test details
  const handleViewDetails = (test: Test) => {
    setSelectedTest(test);
    setShowDetailsModal(true);
  };
  
  // Close details modal
  const handleCloseDetailsModal = () => {
    setShowDetailsModal(false);
  };
  
  // Handle selecting a test for automation
  const handleSelectForAutomation = (test: Test) => {
    setSelectedTestForAutomation(test);
    setActiveDashboardTab("automation");
  };
  
  // Handle selecting a test for reporting
  const handleSelectForReporting = (test: Test) => {
    setSelectedTestForReporting(test);
    setActiveDashboardTab("reporting");
  };

  return (
    <AppLayout title="SRS Testing Dashboard">
      <Tabs className="w-full" value={activeDashboardTab} onValueChange={setActiveDashboardTab}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="main">Main Dashboard</TabsTrigger>
          <TabsTrigger value="automation">Test Automation</TabsTrigger>
          <TabsTrigger value="reporting">Test Reporting</TabsTrigger>
        </TabsList>
        
        <TabsContent value="main">
          {/* Test Creation Card */}
          <TestCreationCard onTestCreated={handleTestCreated} />
          
          {/* Active Tests Section */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Active Tests</h3>
            
            {activeTests.length > 0 ? (
              activeTests.map(test => (
                <div key={test.id} className="mb-4">
                  <TestProgressCard test={test} />
                </div>
              ))
            ) : (
              <div className="bg-white shadow-sm rounded-lg p-8 text-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-8 h-8 mx-auto text-gray-300 mb-2"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M10.24 3.957l-8.422 14.06A1.989 1.989 0 0 0 3.518 21H20.48a1.989 1.989 0 0 0 1.7-2.983l-8.42-14.06a1.989 1.989 0 0 0-3.52 0z" />
                  <path d="M8 10h8" />
                  <path d="M8 14h8" />
                  <path d="M12 18h.01" />
                </svg>
                <h4 className="text-gray-500 font-medium mb-1">No Active Tests</h4>
                <p className="text-sm text-gray-400">Start a new test to see progress here</p>
              </div>
            )}
          </div>
          
          {/* Completed Tests Section */}
          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-4">Completed Tests</h3>
            
            {completedTests.length > 0 ? (
              <div className="space-y-4">
                {completedTests.map(test => (
                  <div key={test.id} className="bg-white rounded-lg shadow-sm p-5">
                    <TestResultCard 
                      test={test} 
                      onViewDetails={handleViewDetails}
                    />
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleSelectForAutomation(test)}
                      >
                        Set Up Test Automation
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleSelectForReporting(test)}
                      >
                        Generate Reports
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white shadow-sm rounded-lg p-8 text-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-8 h-8 mx-auto text-gray-300 mb-2"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                  <line x1="9" y1="9" x2="15" y2="15" />
                  <line x1="15" y1="9" x2="9" y2="15" />
                </svg>
                <h4 className="text-gray-500 font-medium mb-1">No Completed Tests</h4>
                <p className="text-sm text-gray-400">Your completed tests will appear here</p>
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="automation">
          <div className="mb-4 flex">
            <Button 
              variant="outline" 
              onClick={() => setActiveDashboardTab("main")}
              className="mr-2"
            >
              Back to Dashboard
            </Button>
            
            {selectedTestForAutomation && (
              <div className="ml-auto text-sm text-gray-500">
                Configuring automation for: <span className="font-medium">{selectedTestForAutomation.name}</span>
              </div>
            )}
          </div>
          
          {selectedTestForAutomation ? (
            <TestAutomationConfig test={selectedTestForAutomation} />
          ) : (
            <div className="bg-white shadow-sm rounded-lg p-8 text-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-8 h-8 mx-auto text-gray-300 mb-2"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m9.09 9 6.82 6.82" />
                <path d="m15.91 9-6.82 6.82" />
              </svg>
              <h4 className="text-gray-500 font-medium mb-1">No Test Selected</h4>
              <p className="text-sm text-gray-400 mb-4">Please select a completed test to configure automation</p>
              <Button onClick={() => setActiveDashboardTab("main")}>
                Return to Dashboard
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="reporting">
          <div className="mb-4 flex">
            <Button 
              variant="outline" 
              onClick={() => setActiveDashboardTab("main")}
              className="mr-2"
            >
              Back to Dashboard
            </Button>
            
            {selectedTestForReporting && (
              <div className="ml-auto text-sm text-gray-500">
                Generating reports for: <span className="font-medium">{selectedTestForReporting.name}</span>
              </div>
            )}
          </div>
          
          {selectedTestForReporting ? (
            <TestReportingPanel test={selectedTestForReporting} />
          ) : (
            <div className="bg-white shadow-sm rounded-lg p-8 text-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-8 h-8 mx-auto text-gray-300 mb-2"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m9.09 9 6.82 6.82" />
                <path d="m15.91 9-6.82 6.82" />
              </svg>
              <h4 className="text-gray-500 font-medium mb-1">No Test Selected</h4>
              <p className="text-sm text-gray-400 mb-4">Please select a completed test to generate reports</p>
              <Button onClick={() => setActiveDashboardTab("main")}>
                Return to Dashboard
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Test Details Modal */}
      <TestDetailsModal 
        test={selectedTest} 
        isOpen={showDetailsModal} 
        onClose={handleCloseDetailsModal}
      />
    </AppLayout>
  );
};

export default Dashboard;
