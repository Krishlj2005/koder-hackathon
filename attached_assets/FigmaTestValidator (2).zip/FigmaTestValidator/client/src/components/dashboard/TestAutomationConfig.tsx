import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Test } from '@shared/schema';
import { toast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface TestAutomationConfigProps {
  test: Test;
}

const TestAutomationConfig: FC<TestAutomationConfigProps> = ({ test }) => {
  const [automationFramework, setAutomationFramework] = useState<string>('playwright');
  const [selectedBrowsers, setSelectedBrowsers] = useState<string[]>(['chrome']);
  const [customScript, setCustomScript] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [cicdProvider, setCicdProvider] = useState<string>('github');
  const [webhookUrl, setWebhookUrl] = useState<string>('');
  
  const handleBrowserToggle = (browser: string) => {
    if (selectedBrowsers.includes(browser)) {
      setSelectedBrowsers(selectedBrowsers.filter(b => b !== browser));
    } else {
      setSelectedBrowsers([...selectedBrowsers, browser]);
    }
  };
  
  const handleGenerateTests = async () => {
    setIsGenerating(true);
    
    try {
      const response = await fetch(`/api/tests/${test.id}/generate-automation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          framework: automationFramework,
          browsers: selectedBrowsers,
          customScript: customScript || null
        }),
      });
      
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Display sample code or success message
      toast({
        title: "Test Automation Generated",
        description: `Successfully generated automated tests using ${automationFramework}.`,
      });
      
      // Invalidate the test queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/tests'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tests', test.id] });
    } catch (error) {
      toast({
        title: "Failed to Generate Tests",
        description: "There was an error generating the automated tests. Please try again.",
        variant: "destructive"
      });
      console.error("Error generating automated tests:", error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  const handleSetupCICD = async () => {
    try {
      const response = await fetch(`/api/tests/${test.id}/setup-cicd`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          provider: cicdProvider,
          webhookUrl: webhookUrl || null
        }),
      });
      
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      
      toast({
        title: "CI/CD Integration Setup",
        description: `Successfully configured CI/CD integration with ${cicdProvider}.`,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/tests'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tests', test.id] });
    } catch (error) {
      toast({
        title: "Failed to Setup CI/CD",
        description: "There was an error setting up the CI/CD integration. Please try again.",
        variant: "destructive"
      });
      console.error("Error setting up CI/CD:", error);
    }
  };
  
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle>Test Automation & CI/CD Integration</CardTitle>
        <CardDescription>Configure automated testing and continuous integration for your design validation tests</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="automation">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="automation">Test Automation</TabsTrigger>
            <TabsTrigger value="cicd">CI/CD Integration</TabsTrigger>
          </TabsList>
          
          <TabsContent value="automation" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="framework">Automation Framework</Label>
                <Select 
                  value={automationFramework} 
                  onValueChange={setAutomationFramework}
                >
                  <SelectTrigger id="framework">
                    <SelectValue placeholder="Select framework" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="playwright">Playwright</SelectItem>
                    <SelectItem value="cypress">Cypress</SelectItem>
                    <SelectItem value="selenium">Selenium WebDriver</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Target Browsers</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="chrome" 
                      checked={selectedBrowsers.includes('chrome')} 
                      onCheckedChange={() => handleBrowserToggle('chrome')}
                    />
                    <Label htmlFor="chrome">Chrome</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="firefox" 
                      checked={selectedBrowsers.includes('firefox')} 
                      onCheckedChange={() => handleBrowserToggle('firefox')}
                    />
                    <Label htmlFor="firefox">Firefox</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="safari" 
                      checked={selectedBrowsers.includes('safari')} 
                      onCheckedChange={() => handleBrowserToggle('safari')}
                    />
                    <Label htmlFor="safari">Safari</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="edge" 
                      checked={selectedBrowsers.includes('edge')} 
                      onCheckedChange={() => handleBrowserToggle('edge')}
                    />
                    <Label htmlFor="edge">Edge</Label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="customScript">Custom Test Script (Optional)</Label>
                <Textarea 
                  id="customScript" 
                  placeholder="Add custom testing logic here..." 
                  className="min-h-[100px]"
                  value={customScript}
                  onChange={(e) => setCustomScript(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleGenerateTests} 
                disabled={isGenerating || selectedBrowsers.length === 0}
                className="w-full"
              >
                {isGenerating ? "Generating..." : "Generate Automated Tests"}
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="cicd" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="cicdProvider">CI/CD Provider</Label>
                <Select 
                  value={cicdProvider} 
                  onValueChange={setCicdProvider}
                >
                  <SelectTrigger id="cicdProvider">
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="github">GitHub Actions</SelectItem>
                    <SelectItem value="gitlab">GitLab CI</SelectItem>
                    <SelectItem value="jenkins">Jenkins</SelectItem>
                    <SelectItem value="circleci">CircleCI</SelectItem>
                    <SelectItem value="travis">Travis CI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="webhookUrl">Webhook URL (Optional)</Label>
                <Input 
                  id="webhookUrl" 
                  placeholder="https://your-ci-system.com/webhook" 
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                />
                <p className="text-xs text-gray-500 mt-1">
                  For receiving test results in your CI/CD system
                </p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
                <h4 className="font-medium mb-2">Integration Files</h4>
                <p className="text-sm text-gray-600 mb-3">
                  The following configuration files will be generated based on your selected provider:
                </p>
                <ul className="text-xs space-y-1 text-gray-700">
                  {cicdProvider === 'github' && (
                    <>
                      <li>• .github/workflows/design-validation.yml</li>
                      <li>• .github/actions/figma-test-action/action.yml</li>
                    </>
                  )}
                  {cicdProvider === 'gitlab' && (
                    <li>• .gitlab-ci.yml with design validation stage</li>
                  )}
                  {cicdProvider === 'jenkins' && (
                    <li>• Jenkinsfile with design validation pipeline</li>
                  )}
                  {cicdProvider === 'circleci' && (
                    <li>• .circleci/config.yml with design validation job</li>
                  )}
                  {cicdProvider === 'travis' && (
                    <li>• .travis.yml with design validation stage</li>
                  )}
                </ul>
              </div>
              
              <Button 
                onClick={handleSetupCICD} 
                className="w-full"
              >
                Setup CI/CD Integration
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TestAutomationConfig;