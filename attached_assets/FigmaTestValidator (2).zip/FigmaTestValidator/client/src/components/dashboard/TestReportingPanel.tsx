import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Test } from '@shared/schema';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface TestReportingPanelProps {
  test: Test;
}

const TestReportingPanel: FC<TestReportingPanelProps> = ({ test }) => {
  const [reportFormat, setReportFormat] = useState<string>('pdf');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [activeReportTab, setActiveReportTab] = useState<string>('summary');

  // Sample data for demonstration purposes
  const overallStatusData = [
    { name: 'Passed', value: test.passedRequirements || 0, color: '#10b981' },
    { name: 'Partial', value: test.partialRequirements || 0, color: '#f59e0b' },
    { name: 'Failed', value: test.failedRequirements || 0, color: '#ef4444' }
  ];

  const categoryData = [
    { name: 'UI Elements', passed: 12, partial: 3, failed: 1 },
    { name: 'Navigation', passed: 8, partial: 1, failed: 0 },
    { name: 'Functionality', passed: 15, partial: 2, failed: 4 },
    { name: 'Accessibility', passed: 5, partial: 2, failed: 2 }
  ];

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    
    try {
      const response = await apiRequest(`/api/tests/${test.id}/generate-report`, 'POST', {
        format: reportFormat
      });
      
      const reportData = await response.json();
      
      // In a real app, we would process the report URL here
      const mockReportUrl = `https://api.example.com/reports/${test.id}_${Date.now()}.${reportFormat}`;
      
      toast({
        title: "Report Generated",
        description: `Successfully generated ${reportFormat.toUpperCase()} report. Download will start automatically.`,
      });
      
      // Simulate download start
      // In a real application, we would use the actual URL from the API response
      setTimeout(() => {
        const link = document.createElement('a');
        link.href = mockReportUrl;
        link.download = `test_report_${test.id}.${reportFormat}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }, 1000);
      
    } catch (error) {
      toast({
        title: "Failed to Generate Report",
        description: "There was an error generating the report. Please try again.",
        variant: "destructive"
      });
      console.error("Error generating report:", error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle>Test Reporting & Analytics</CardTitle>
        <CardDescription>View detailed test results and generate comprehensive reports</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="summary" onValueChange={setActiveReportTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="details">Detailed Analysis</TabsTrigger>
            <TabsTrigger value="export">Export Report</TabsTrigger>
          </TabsList>
          
          <TabsContent value="summary" className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-800 mb-2">Test Execution Summary</h4>
              <div className="grid grid-cols-3 gap-4 text-center mb-4">
                <div className="p-3 bg-white rounded-md border border-gray-200">
                  <div className="text-2xl font-bold text-green-500">{test.passedRequirements || 0}</div>
                  <div className="text-sm text-gray-500">Passed Requirements</div>
                </div>
                <div className="p-3 bg-white rounded-md border border-gray-200">
                  <div className="text-2xl font-bold text-yellow-500">{test.partialRequirements || 0}</div>
                  <div className="text-sm text-gray-500">Partial Requirements</div>
                </div>
                <div className="p-3 bg-white rounded-md border border-gray-200">
                  <div className="text-2xl font-bold text-red-500">{test.failedRequirements || 0}</div>
                  <div className="text-sm text-gray-500">Failed Requirements</div>
                </div>
              </div>
              
              <div className="h-[200px] mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={overallStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {overallStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              <div className="text-sm text-gray-500 text-center mt-2">
                Overall Pass Rate: <span className="font-medium text-blue-600">{test.passRate || 0}%</span>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="details" className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-800 mb-2">Requirements by Category</h4>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={categoryData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="passed" stackId="a" fill="#10b981" name="Passed" />
                    <Bar dataKey="partial" stackId="a" fill="#f59e0b" name="Partial" />
                    <Bar dataKey="failed" stackId="a" fill="#ef4444" name="Failed" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="mt-4">
                <h4 className="font-medium text-gray-800 mb-2">Key Observations</h4>
                <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                  <li>Strongest area: Navigation with 100% pass rate in critical requirements</li>
                  <li>Most issues found in Functionality components</li>
                  <li>Accessibility improvements needed in form elements</li>
                  <li>UI Element implementation shows good consistency at 80%</li>
                </ul>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="export" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="reportFormat">Report Format</Label>
                <Select 
                  value={reportFormat} 
                  onValueChange={setReportFormat}
                >
                  <SelectTrigger id="reportFormat">
                    <SelectValue placeholder="Select format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf">PDF Document</SelectItem>
                    <SelectItem value="html">HTML Report</SelectItem>
                    <SelectItem value="xlsx">Excel Spreadsheet</SelectItem>
                    <SelectItem value="json">JSON Data</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-gray-50 rounded-md border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Report Contents</h5>
                  <ul className="text-xs text-gray-600 space-y-1">
                    <li>• Executive Summary</li>
                    <li>• Detailed Test Results</li>
                    <li>• Requirements Coverage Analysis</li>
                    <li>• Visual Design Mapping</li>
                    <li>• Recommendations & Next Steps</li>
                  </ul>
                </div>
                <div className="p-3 bg-gray-50 rounded-md border border-gray-200">
                  <h5 className="font-medium text-gray-700 mb-1">Available Data</h5>
                  <ul className="text-xs text-gray-600 space-y-1">
                    <li>• {test.totalRequirements || 0} Total Requirements</li>
                    <li>• {test.passedRequirements || 0} Passed Tests</li>
                    <li>• {test.partialRequirements || 0} Partial Passes</li>
                    <li>• {test.failedRequirements || 0} Failed Tests</li>
                    <li>• Figma Design File References</li>
                  </ul>
                </div>
              </div>
              
              <Button 
                onClick={handleGenerateReport} 
                disabled={isGenerating}
                className="w-full"
              >
                {isGenerating ? "Generating..." : `Generate ${reportFormat.toUpperCase()} Report`}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TestReportingPanel;