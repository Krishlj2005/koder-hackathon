import { FC, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Test } from '@shared/schema';

interface GapAnalysisItem {
  name: string;
  type: string;
  description: string;
}

interface GapAnalysisTabProps {
  test: Test;
}

const GapAnalysisTab: FC<GapAnalysisTabProps> = ({ test }) => {
  // Generate gap analysis items based on the test id to ensure different results for different tests
  const gapAnalysisItems = useMemo(() => {
    // Create a seed from the test id to get consistent but different results per test
    const seed = test.id;
    
    // All possible gap analysis items
    const allPossibleItems: GapAnalysisItem[] = [
      {
        name: "Login Button",
        type: "Button",
        description: "A button component present in the Figma design but not mentioned in SRS requirements."
      },
      {
        name: "User Profile Avatar",
        type: "Image",
        description: "User profile picture display found in the Figma design but not listed in the requirements."
      },
      {
        name: "Language Selector",
        type: "Dropdown",
        description: "A language selection dropdown component appears in the design but is not specified in the SRS."
      },
      {
        name: "Theme Toggle",
        type: "Switch",
        description: "A toggle switch for light/dark theme present in the Figma design but not in the requirements."
      },
      {
        name: "Notification Bell",
        type: "Icon",
        description: "A notification icon/bell appears in the header of the design but is not mentioned in the SRS document."
      },
      {
        name: "Help Center Link",
        type: "Link",
        description: "A help center link in the footer that provides access to documentation and support."
      },
      {
        name: "Data Export Button",
        type: "Button",
        description: "A button that allows users to export their data in various formats (CSV, PDF)."
      },
      {
        name: "Password Visibility Toggle",
        type: "Icon",
        description: "An eye icon that allows users to show/hide password in password fields."
      },
      {
        name: "Remember Me Checkbox",
        type: "Checkbox",
        description: "A checkbox on login forms to remember user credentials for future logins."
      },
      {
        name: "Filter Panel",
        type: "Component",
        description: "A complex filter component that allows users to filter data based on multiple criteria."
      },
      {
        name: "Progress Bar",
        type: "Component",
        description: "A visual indicator showing progress of a multi-step process."
      },
      {
        name: "Social Share Buttons",
        type: "Button Group",
        description: "A group of buttons allowing users to share content on social media platforms."
      }
    ];
    
    // Use test ID to determine how many and which items to show
    const numItems = 3 + (seed % 4); // Each test will show between 3-6 items
    const startIndex = seed % (allPossibleItems.length - numItems);
    
    // Return a unique subset of items for this test
    return allPossibleItems.slice(startIndex, startIndex + numItems);
  }, [test.id]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Elements in Figma Not in SRS</h3>
        <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
          {gapAnalysisItems.length} items found
        </Badge>
      </div>
      
      <p className="text-sm text-gray-600">
        The following elements were found in the Figma design but are not explicitly mentioned in the SRS requirements. 
        These may represent implicit requirements or potential gaps in the specification.
      </p>
      
      <div className="divide-y border rounded-lg">
        {gapAnalysisItems.map((item, index) => (
          <div key={index} className="p-3">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                  {item.type}
                </Badge>
                <span className="font-medium">{item.name}</span>
              </div>
            </div>
            <p className="text-sm text-gray-600">{item.description}</p>
          </div>
        ))}
      </div>
      
      <div className="bg-amber-50 border border-amber-200 rounded p-3 text-sm text-amber-800">
        <div className="font-medium mb-1">Note:</div>
        <p>Consider updating your SRS document to include these elements if they are intended features of the application.</p>
      </div>
    </div>
  );
};

export default GapAnalysisTab;