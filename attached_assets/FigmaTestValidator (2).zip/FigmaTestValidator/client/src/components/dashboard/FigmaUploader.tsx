import { FC, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface FigmaUploaderProps {
  figmaUrl: string;
  setFigmaUrl: (url: string) => void;
  onFileSelect: (file: File) => void;
}

const FigmaUploader: FC<FigmaUploaderProps> = ({ 
  figmaUrl, 
  setFigmaUrl, 
  onFileSelect 
}) => {
  const [activeTab, setActiveTab] = useState<string>("url");
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setFileName(files[0].name);
      onFileSelect(files[0]);
      setFigmaUrl(''); // Clear URL if file is selected
    }
  };

  const handleUrlChange = (url: string) => {
    setFigmaUrl(url);
    setFileName(null); // Clear file if URL is entered
  };

  const clearFigmaUrl = () => {
    setFigmaUrl('');
    setFileName(null);
  };

  const useSampleUrl = () => {
    setFigmaUrl('https://www.figma.com/file/example/login-page-design');
    setFileName(null);
  };

  return (
    <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-4">
      <div className="text-center mb-3">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="w-8 h-8 mx-auto text-gray-400 mb-3"
          viewBox="0 0 38 57"
          fill="none"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M19 28.5C21.4853 28.5 23.5 26.4853 23.5 24C23.5 21.5147 21.4853 19.5 19 19.5C16.5147 19.5 14.5 21.5147 14.5 24C14.5 26.4853 16.5147 28.5 19 28.5ZM19 38C21.4853 38 23.5 35.9853 23.5 33.5C23.5 31.0147 21.4853 29 19 29C16.5147 29 14.5 31.0147 14.5 33.5C14.5 35.9853 16.5147 38 19 38ZM28.5 24C28.5 26.4853 26.4853 28.5 24 28.5C21.5147 28.5 19.5 26.4853 19.5 24C19.5 21.5147 21.5147 19.5 24 19.5C26.4853 19.5 28.5 21.5147 28.5 24ZM19 19C21.4853 19 23.5 16.9853 23.5 14.5C23.5 12.0147 21.4853 10 19 10C16.5147 10 14.5 12.0147 14.5 14.5C14.5 16.9853 16.5147 19 19 19Z"
            fill="#1E1E1E"
          />
        </svg>
        <h4 className="text-md font-medium text-gray-700 mb-1">Connect Figma Design</h4>
        <p className="text-sm text-gray-500">Use a Figma URL or upload a Figma file</p>
      </div>
      
      <Tabs defaultValue="url" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="url">Figma URL</TabsTrigger>
          <TabsTrigger value="file">File Upload</TabsTrigger>
        </TabsList>
        
        <TabsContent value="url" className="space-y-4">
          <div className="space-y-2">
            <Input
              type="text"
              placeholder="https://www.figma.com/file/..."
              value={figmaUrl}
              onChange={(e) => handleUrlChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            />
            
            {figmaUrl && (
              <div className="flex items-center p-2 bg-blue-50 rounded border border-blue-100 text-sm">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="9 11 12 14 22 4"></polyline>
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
                <span className="text-blue-700 truncate">{figmaUrl}</span>
              </div>
            )}
          </div>
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              size="sm" 
              onClick={clearFigmaUrl}
              disabled={!figmaUrl}
            >
              Clear
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              size="sm" 
              onClick={useSampleUrl}
              className="text-primary-600 border-primary-600 hover:bg-primary-50"
            >
              Use Sample
            </Button>
          </div>
          
          <div className="text-xs text-gray-500 mt-2">
            <p className="font-medium">Figma URL Format:</p>
            <ul className="list-disc list-inside">
              <li>Must be a valid Figma file URL</li>
              <li>File must be set to allow viewer access</li>
              <li>Example: https://www.figma.com/file/example/my-design</li>
            </ul>
          </div>
        </TabsContent>
        
        <TabsContent value="file">
          <div className="flex flex-col items-center justify-center h-48 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 p-6">
            {fileName ? (
              <div className="text-center">
                <Badge variant="outline" className="mb-2 bg-violet-50 text-violet-700 border-violet-200">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-3 h-3 mr-1"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                  </svg>
                  File Selected
                </Badge>
                <p className="font-medium text-sm">{fileName}</p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="mt-2 text-xs text-red-600"
                  onClick={clearFigmaUrl}
                >
                  Remove
                </Button>
              </div>
            ) : (
              <>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-10 h-10 text-gray-400 mb-3"
                  viewBox="0 0 38 57"
                  fill="none"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M19 28.5C21.4853 28.5 23.5 26.4853 23.5 24C23.5 21.5147 21.4853 19.5 19 19.5C16.5147 19.5 14.5 21.5147 14.5 24C14.5 26.4853 16.5147 28.5 19 28.5ZM19 38C21.4853 38 23.5 35.9853 23.5 33.5C23.5 31.0147 21.4853 29 19 29C16.5147 29 14.5 31.0147 14.5 33.5C14.5 35.9853 16.5147 38 19 38ZM28.5 24C28.5 26.4853 26.4853 28.5 24 28.5C21.5147 28.5 19.5 26.4853 19.5 24C19.5 21.5147 21.5147 19.5 24 19.5C26.4853 19.5 28.5 21.5147 28.5 24ZM19 19C21.4853 19 23.5 16.9853 23.5 14.5C23.5 12.0147 21.4853 10 19 10C16.5147 10 14.5 12.0147 14.5 14.5C14.5 16.9853 16.5147 19 19 19Z"
                    fill="#1E1E1E"
                  />
                </svg>
                <p className="mb-2 text-sm text-gray-700">
                  <span className="font-medium">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-gray-500">
                  Figma (.fig) files only
                </p>
                <label className="mt-4 cursor-pointer">
                  <Button variant="default" size="sm">Select File</Button>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept=".fig"
                    onChange={handleFileChange}
                  />
                </label>
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FigmaUploader;
