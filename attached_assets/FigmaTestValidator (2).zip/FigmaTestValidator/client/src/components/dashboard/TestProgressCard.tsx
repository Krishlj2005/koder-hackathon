import { FC, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';
import { Test } from '@shared/schema';

interface TestProgressCardProps {
  test: Test;
}

const TestProgressCard: FC<TestProgressCardProps> = ({ test }) => {
  const startedTime = new Date(test.createdAt);
  const timeAgo = formatDistanceToNow(startedTime, { addSuffix: true });
  const [animatedProgress, setAnimatedProgress] = useState(0);
  
  // Animate progress bar
  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedProgress(test.progress ?? 0);
    }, 300);
    
    return () => clearTimeout(timer);
  }, [test.progress]);
  
  // Generate a list of active phases based on progress
  const getPhases = () => {
    const progress = test.progress ?? 0;
    const phases = [
      { name: "Analysis", percent: 20, active: progress >= 20 },
      { name: "Loading Figma", percent: 40, active: progress >= 40 },
      { name: "Extracting Elements", percent: 60, active: progress >= 60 },
      { name: "Comparing", percent: 80, active: progress >= 80 },
      { name: "Finalizing", percent: 100, active: progress >= 100 }
    ];
    
    return phases;
  };
  
  const phases = getPhases();
  const currentPhase = phases.filter(phase => phase.active).pop() || phases[0];
  
  return (
    <Card className="bg-white shadow-sm rounded-lg overflow-hidden mb-4 border-l-4 border-blue-500">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h4 className="font-medium text-gray-800">{test.name}</h4>
          <p className="text-sm text-gray-500">Started {timeAgo}</p>
        </div>
        <div>
          <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100 animate-pulse">
            <span className="mr-1 inline-block h-2 w-2 rounded-full bg-blue-500"></span>
            In Progress
          </Badge>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="mb-2 flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">
            {currentPhase.name} ({test.progress ?? 0}%)
          </span>
          <span className="text-sm font-medium text-blue-600">
            {(test.progress ?? 0) < 100 ? "Processing..." : "Complete"}
          </span>
        </div>
        <Progress value={animatedProgress} className="w-full h-2.5 bg-gray-200" />
        
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          {phases.map((phase, index) => (
            <div key={index} className="flex flex-col items-center">
              <div 
                className={`w-2 h-2 rounded-full ${
                  phase.active ? 'bg-blue-500' : 'bg-gray-300'
                }`}
              />
              {index === 0 || index === phases.length - 1 ? (
                <span className={phase.active ? 'text-blue-600' : 'text-gray-400'}>
                  {phase.name}
                </span>
              ) : null}
            </div>
          ))}
        </div>
        
        <div className="mt-4 grid grid-cols-3 gap-4 p-2 rounded-lg bg-gray-50">
          <div className="flex flex-col items-center justify-center p-2 rounded border border-gray-200 bg-white">
            <div className="text-lg font-medium text-gray-800">{test.totalRequirements || "?"}</div>
            <div className="text-xs text-gray-500">Total Requirements</div>
          </div>
          <div className="flex flex-col items-center justify-center p-2 rounded border border-gray-200 bg-white">
            <div className="text-lg font-medium text-green-600">{test.passedRequirements || "0"}</div>
            <div className="text-xs text-gray-500">Passed</div>
          </div>
          <div className="flex flex-col items-center justify-center p-2 rounded border border-gray-200 bg-white">
            <div className="text-lg font-medium text-red-600">{test.failedRequirements || "0"}</div>
            <div className="text-xs text-gray-500">Failed</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestProgressCard;
