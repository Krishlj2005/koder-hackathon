import { FC, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';
import { Test } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';

interface TestResultCardProps {
  test: Test;
  onViewDetails: (test: Test) => void;
}

type RequirementStatus = {
  status: 'passed' | 'partial' | 'failed';
  description: string;
  analysisNotes: string;
};

const TestResultCard: FC<TestResultCardProps> = ({ test, onViewDetails }) => {
  const [showResults, setShowResults] = useState(false);
  
  const { data: requirements } = useQuery({
    queryKey: [`/api/tests/${test.id}/requirements`],
    enabled: showResults, // Only fetch when expanded
  });
  
  const completedTime = test.completedAt ? new Date(test.completedAt) : new Date(test.createdAt);
  const timeAgo = formatDistanceToNow(completedTime, { addSuffix: true });
  
  // Get the first 3 requirements for display
  const previewRequirements = requirements?.slice(0, 3) || [];
  
  const handleExport = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering card expansion
    
    // In a real implementation, we would generate and download a PDF/CSV report
    alert('Export functionality would generate a PDF or CSV report');
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'border-green-500 bg-white';
      case 'partial': return 'border-yellow-500 bg-white';
      case 'failed': return 'border-red-500 bg-white';
      default: return 'border-gray-200 bg-white';
    }
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return (
          <div className="text-green-500 mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-5 h-5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
          </div>
        );
      case 'partial':
        return (
          <div className="text-yellow-500 mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-5 h-5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
          </div>
        );
      case 'failed':
        return (
          <div className="text-red-500 mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-5 h-5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="15" y1="9" x2="9" y2="15" />
              <line x1="9" y1="9" x2="15" y2="15" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Card className="bg-white shadow-sm rounded-lg overflow-hidden mb-4">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h4 className="font-medium text-gray-800">{test.name}</h4>
          <p className="text-sm text-gray-500">Completed {timeAgo}</p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-sm text-primary-600 hover:text-primary-700"
            onClick={handleExport}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-4 h-4 mr-1"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Export
          </Button>
          <Button variant="ghost" size="sm" className="text-sm text-gray-600 hover:text-gray-800">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-4 h-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="1" />
              <circle cx="12" cy="5" r="1" />
              <circle cx="12" cy="19" r="1" />
            </svg>
          </Button>
        </div>
      </div>
      <CardContent className="p-4 space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-sm font-medium text-gray-700">Test Results</div>
            <div className="mt-1 text-sm text-gray-500">
              {test.passedRequirements} out of {test.totalRequirements} requirements fulfilled
            </div>
          </div>
          <div>
            <span className="text-lg font-bold text-green-600">{test.passRate}%</span>
          </div>
        </div>
        
        {showResults && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex space-x-2 mb-4">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-3.5 h-3.5 mr-1"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                  <polyline points="22 4 12 14.01 9 11.01" />
                </svg>
                {test.passedRequirements} Passed
              </Badge>
              <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-3.5 h-3.5 mr-1"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="12" />
                  <line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                {test.partialRequirements} Partial
              </Badge>
              <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-3.5 h-3.5 mr-1"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10" />
                  <line x1="15" y1="9" x2="9" y2="15" />
                  <line x1="9" y1="9" x2="15" y2="15" />
                </svg>
                {test.failedRequirements} Failed
              </Badge>
            </div>
            
            <div className="space-y-2 text-sm">
              {previewRequirements.map((req) => (
                <div 
                  key={req.id}
                  className={`flex items-start p-2 border-l-4 rounded ${getStatusColor(req.status)}`}
                >
                  {getStatusIcon(req.status)}
                  <div className="flex-1">
                    <p className="font-medium text-gray-800">{req.description}</p>
                    <p className="text-xs text-gray-500">{req.analysisNotes}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-3 text-center">
              <Button 
                variant="link" 
                className="text-sm text-primary-600 hover:text-primary-700 font-medium"
                onClick={() => onViewDetails(test)}
              >
                View Full Report
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-4 h-4 ml-1"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="5" y1="12" x2="19" y2="12" />
                  <polyline points="12 5 19 12 12 19" />
                </svg>
              </Button>
            </div>
          </div>
        )}
        
        {!showResults && (
          <Button 
            variant="outline" 
            className="w-full py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            onClick={() => setShowResults(true)}
          >
            Show Details
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default TestResultCard;
