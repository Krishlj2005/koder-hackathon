import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import FigmaUploader from './FigmaUploader';
import SRSUploader from './SRSUploader';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

const TestCreationCard: FC<{ onTestCreated: () => void }> = ({ onTestCreated }) => {
  const [testName, setTestName] = useState('');
  const [figmaUrl, setFigmaUrl] = useState('');
  const [figmaFile, setFigmaFile] = useState<File | null>(null);
  const [srsText, setSrsText] = useState('');
  const [srsFile, setSrsFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { toast } = useToast();

  const handleFigmaFileSelect = (file: File) => {
    setFigmaFile(file);
    setFigmaUrl(''); // Clear URL when file is selected
  };

  const handleSrsFileSelect = (file: File) => {
    setSrsFile(file);
    // In a real implementation, we would parse the file contents
    // and set the SRS text. Here, we'll just clear it for now.
    setSrsText('');
  };

  const handleSubmit = async () => {
    if (!testName) {
      toast({
        title: "Error",
        description: "Please provide a test name",
        variant: "destructive"
      });
      return;
    }

    if (!figmaUrl && !figmaFile) {
      toast({
        title: "Error",
        description: "Please provide a Figma file URL or upload a Figma file",
        variant: "destructive"
      });
      return;
    }
    
    if (!srsText && !srsFile) {
      toast({
        title: "Error",
        description: "Please provide SRS requirements or upload an SRS document",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      // In a real implementation, we would handle file uploads
      // For now, we'll just send the text data
      const response = await apiRequest('POST', '/api/create-test', {
        name: testName,
        figmaUrl,
        srsText
      });
      
      const data = await response.json();
      
      toast({
        title: "Success",
        description: "Test created successfully",
      });
      
      // Simulate a test running (in a real app, this would be triggered by the backend)
      if (data.testId) {
        await apiRequest('POST', `/api/simulate-test/${data.testId}`, {});
      }
      
      // Reset form
      setTestName('');
      setFigmaUrl('');
      setFigmaFile(null);
      setSrsText('');
      setSrsFile(null);
      
      // Notify parent component to refresh tests
      onTestCreated();
    } catch (error) {
      console.error("Error creating test:", error);
      toast({
        title: "Error",
        description: "Failed to create test",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="bg-white shadow-sm rounded-lg overflow-hidden mb-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Create New Test</h3>
        
        <div className="mb-4">
          <label htmlFor="test-name" className="block text-sm font-medium text-gray-700 mb-1">
            Test Name
          </label>
          <Input
            id="test-name"
            placeholder="Enter a name for this test"
            value={testName}
            onChange={(e) => setTestName(e.target.value)}
            className="w-full"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FigmaUploader 
            figmaUrl={figmaUrl} 
            setFigmaUrl={setFigmaUrl} 
            onFileSelect={handleFigmaFileSelect} 
          />
          <SRSUploader 
            srsText={srsText} 
            setSrsText={setSrsText} 
            onFileSelect={handleSrsFileSelect} 
          />
        </div>
        
        <div className="mt-6 text-right">
          <Button 
            onClick={handleSubmit}
            disabled={isSubmitting}
            variant="default"
            size="lg"
            className="w-full md:w-auto"
          >
            {isSubmitting ? "Processing..." : "Run Test"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestCreationCard;
