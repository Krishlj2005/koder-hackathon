import { FC, useState } from 'react';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Test, Requirement } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import GapAnalysisTab from './GapAnalysisTab';

// Extended Requirement type to ensure proper typing of figmaElements and missingElements
interface RequirementWithElements extends Requirement {
  figmaElements: string[];
  missingElements: string[];
}

interface TestDetailsModalProps {
  test: Test | null;
  isOpen: boolean;
  onClose: () => void;
}

const TestDetailsModal: FC<TestDetailsModalProps> = ({ test, isOpen, onClose }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'passed' | 'partial' | 'failed'>('all');
  const [expandedRequirements, setExpandedRequirements] = useState<Set<number>>(new Set());
  const [activeTab, setActiveTab] = useState<string>("requirements");
  
  const { data: requirements = [] } = useQuery<RequirementWithElements[]>({
    queryKey: test ? [`/api/tests/${test.id}/requirements`] : [],
    enabled: isOpen && !!test,
  });

  if (!test) return null;
  
  const completedDate = test.completedAt ? new Date(test.completedAt) : null;
  const formattedDate = completedDate ? format(completedDate, 'MMMM d, yyyy') : 'N/A';
  
  const filteredRequirements = requirements.filter((req) => {
    if (activeFilter === 'all') return true;
    return req.status === activeFilter;
  });
  
  const toggleExpand = (id: number) => {
    const newExpanded = new Set(expandedRequirements);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRequirements(newExpanded);
  };
  
  const exportReport = () => {
    // In a real implementation, we would generate and download a PDF report
    alert('Export functionality would generate a PDF report');
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-gray-800">
            Test Report: {test.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="overflow-y-auto max-h-[calc(90vh-8rem)]">
          {/* Report Content */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h4 className="text-md font-medium text-gray-800">Summary</h4>
                <p className="text-sm text-gray-500">Test completed on {formattedDate}</p>
              </div>
              <Button 
                className="px-3 py-1.5 bg-primary-600 text-white text-sm rounded hover:bg-primary-700"
                onClick={exportReport}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-4 h-4 mr-1"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                Export Report
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold text-gray-800">{test.totalRequirements}</div>
                <div className="text-sm text-gray-500">Total Requirements</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold text-green-600">{test.passedRequirements}</div>
                <div className="text-sm text-green-600">Passed</div>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold text-yellow-600">{test.partialRequirements}</div>
                <div className="text-sm text-yellow-600">Partial</div>
              </div>
              <div className="bg-red-50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold text-red-600">{test.failedRequirements}</div>
                <div className="text-sm text-red-600">Failed</div>
              </div>
            </div>
          </div>
          
          <Tabs defaultValue="requirements" value={activeTab} onValueChange={setActiveTab} className="mt-6">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="requirements">Requirement Analysis</TabsTrigger>
              <TabsTrigger value="gap-analysis">Gap Analysis</TabsTrigger>
            </TabsList>
            
            <TabsContent value="requirements">
              <h4 className="text-md font-medium text-gray-800 mb-3">Requirement Analysis</h4>
              
              <div className="mb-4 flex border border-gray-200 rounded-md">
                <Button 
                  onClick={() => setActiveFilter('all')}
                  className={`flex-1 py-2 text-center text-sm font-medium rounded-l ${
                    activeFilter === 'all' 
                      ? 'text-white bg-primary-600'
                      : 'text-gray-700'
                  }`}
                >
                  All ({requirements.length})
                </Button>
                <Button 
                  onClick={() => setActiveFilter('passed')}
                  className={`flex-1 py-2 text-center text-sm font-medium ${
                    activeFilter === 'passed' 
                      ? 'text-white bg-primary-600'
                      : 'text-gray-700'
                  }`}
                >
                  Passed ({test.passedRequirements})
                </Button>
                <Button 
                  onClick={() => setActiveFilter('partial')}
                  className={`flex-1 py-2 text-center text-sm font-medium ${
                    activeFilter === 'partial' 
                      ? 'text-white bg-primary-600'
                      : 'text-gray-700'
                  }`}
                >
                  Partial ({test.partialRequirements})
                </Button>
                <Button 
                  onClick={() => setActiveFilter('failed')}
                  className={`flex-1 py-2 text-center text-sm font-medium rounded-r ${
                    activeFilter === 'failed' 
                      ? 'text-white bg-primary-600'
                      : 'text-gray-700'
                  }`}
                >
                  Failed ({test.failedRequirements})
                </Button>
              </div>
            
              <div className="space-y-3">
                {filteredRequirements.map((req) => {
                  const isExpanded = expandedRequirements.has(req.id);
                  const borderColor = req.status === 'passed' 
                    ? 'border-green-500' 
                    : req.status === 'partial' 
                      ? 'border-yellow-500' 
                      : 'border-red-500';
                  
                  const textColor = req.status === 'passed' 
                    ? 'text-green-500' 
                    : req.status === 'partial' 
                      ? 'text-yellow-500' 
                      : 'text-red-500';
                  
                  return (
                    <div key={req.id} className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className={`flex items-center p-3 bg-white border-l-4 ${borderColor}`}>
                        <div className="flex-1">
                          <div className="flex items-start">
                            <div className={`${textColor} mr-2`}>
                              {req.status === 'passed' ? (
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  className="w-5 h-5"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                                  <polyline points="22 4 12 14.01 9 11.01" />
                                </svg>
                              ) : req.status === 'partial' ? (
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  className="w-5 h-5"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="12" cy="12" r="10" />
                                  <line x1="12" y1="8" x2="12" y2="12" />
                                  <line x1="12" y1="16" x2="12.01" y2="16" />
                                </svg>
                              ) : (
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  className="w-5 h-5"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="12" cy="12" r="10" />
                                  <line x1="15" y1="9" x2="9" y2="15" />
                                  <line x1="9" y1="9" x2="15" y2="15" />
                                </svg>
                              )}
                            </div>
                            <div>
                              <h5 className="font-medium text-gray-800">{req.description}</h5>
                              <p className="text-xs text-gray-500">
                                {req.code}: {req.description}
                              </p>
                            </div>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-400 hover:text-gray-600"
                          onClick={() => toggleExpand(req.id)}
                        >
                          {isExpanded ? (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="w-5 h-5"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="18 15 12 9 6 15" />
                            </svg>
                          ) : (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="w-5 h-5"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="6 9 12 15 18 9" />
                            </svg>
                          )}
                        </Button>
                      </div>
                      {isExpanded && (
                        <div className="p-3 bg-gray-50">
                          {req.figmaElements && req.figmaElements.length > 0 && (
                            <div className="mb-2">
                              <div className="text-xs text-gray-500 mb-1">Figma Elements Found:</div>
                              <ul className="text-sm text-gray-700 pl-5 list-disc">
                                {Array.isArray(req.figmaElements) && req.figmaElements.map((elem, i) => (
                                  <li key={i}>{elem}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {req.missingElements && req.missingElements.length > 0 && (
                            <div className="mb-2">
                              <div className="text-xs text-gray-500 mb-1">Missing Elements:</div>
                              <ul className="text-sm text-gray-700 pl-5 list-disc">
                                {Array.isArray(req.missingElements) && req.missingElements.map((elem, i) => (
                                  <li key={i}>{elem}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          <div>
                            <div className="text-xs text-gray-500 mb-1">Confidence Score:</div>
                            <div className={`font-medium ${textColor}`}>{req.confidence}%</div>
                          </div>
                          
                          {req.status === 'failed' && (
                            <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-700">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="w-4 h-4 inline mr-1"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
                                <path d="M12 9v4" />
                                <path d="M12 17h.01" />
                              </svg>
                              Recommendation: Add the missing elements to the design
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-8">
                <h4 className="text-md font-medium text-gray-800 mb-3">Visual Coverage Analysis</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="aspect-w-16 aspect-h-9 bg-gray-200 rounded-lg flex items-center justify-center">
                    <div className="text-gray-500 text-sm">Figma design coverage visualization would appear here</div>
                  </div>
                  <div className="mt-3 text-sm text-gray-600">
                    This visualization shows which areas of the design are covered by requirements and which might need attention.
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="gap-analysis">
              <GapAnalysisTab test={test} />
            </TabsContent>
          </Tabs>
        </div>
        
        <DialogFooter className="border-t border-gray-200 pt-4">
          <Button 
            variant="outline" 
            className="bg-gray-200 text-gray-800 hover:bg-gray-300 mr-2"
            onClick={onClose}
          >
            Close
          </Button>
          <Button className="bg-primary-600 text-white hover:bg-primary-700">
            Generate Improvement Report
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default TestDetailsModal;