import { FC, useState } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface SRSUploaderProps {
  srsText: string;
  setSrsText: (text: string) => void;
  onFileSelect: (file: File) => void;
}

const SRSUploader: FC<SRSUploaderProps> = ({ 
  srsText, 
  setSrsText, 
  onFileSelect 
}) => {
  const [activeTab, setActiveTab] = useState<string>("manual");
  const [fileName, setFileName] = useState<string | null>(null);

  // Example requirements templates
  const templateOptions = [
    {
      name: "Login Page Template",
      requirements: `UI-001: The login page must have a username field
UI-002: The login page must have a password field
UI-003: The login page must have a "Forgot Password" link
UI-004: The login page must have a "Remember Me" checkbox
UI-005: The login page must have a submit button
UI-006: The login page must display validation errors
UI-007: The login page must have responsive design for mobile devices
UI-008: The login page must have a link to registration page
UI-009: The login page must support dark mode`
    },
    {
      name: "Dashboard Template",
      requirements: `UI-101: The dashboard must display a summary of recent activity
UI-102: The dashboard must include a navigation sidebar
UI-103: The dashboard must have a search function
UI-104: The dashboard must display user profile information
UI-105: The dashboard must include notification indicators
UI-106: The dashboard must have responsive layout for various devices
UI-107: The dashboard must include data visualization components
UI-108: The dashboard must support theme customization
UI-109: The dashboard must have a help/support section`
    },
    {
      name: "E-commerce Template",
      requirements: `UI-201: The product page must display product images
UI-202: The product page must show pricing information
UI-203: The product page must have an "Add to Cart" button
UI-204: The product page must show product reviews and ratings
UI-205: The product page must display related products
UI-206: The product page must have size/color selection options
UI-207: The product page must show availability status
UI-208: The product page must have social sharing buttons
UI-209: The product page must be mobile responsive`
    },
    {
      name: "Form Template",
      requirements: `UI-301: Form must have appropriate input fields with labels
UI-302: Form must validate user input in real-time
UI-303: Form must highlight errors with clear error messages
UI-304: Form must have a submit button
UI-305: Form must show progress indicator for multi-step forms
UI-306: Form must have responsive design for all devices
UI-307: Form must support autosave functionality
UI-308: Form must provide visual feedback on successful submission
UI-309: Form must be accessible and support screen readers`
    }
  ];
  
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setFileName(files[0].name);
      onFileSelect(files[0]);
    }
  };

  const useTemplate = (index: number) => {
    setSelectedTemplate(index);
    setSrsText(templateOptions[index].requirements);
  };

  const clearSrsText = () => {
    setSrsText("");
    setFileName(null);
  };

  return (
    <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-4">
      <div className="text-center mb-3">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="w-8 h-8 mx-auto text-gray-400 mb-3"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
          <polyline points="14 2 14 8 20 8" />
        </svg>
        <h4 className="text-md font-medium text-gray-700 mb-1">Upload SRS Requirements</h4>
        <p className="text-sm text-gray-500">Upload a document or paste SRS requirements</p>
      </div>
      
      <Tabs defaultValue="manual" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="manual">Manual Entry</TabsTrigger>
          <TabsTrigger value="file">File Upload</TabsTrigger>
        </TabsList>
        
        <TabsContent value="manual" className="space-y-4">
          <Textarea
            placeholder="Enter SRS requirements here, one per line"
            value={srsText}
            onChange={(e) => setSrsText(e.target.value)}
            rows={5}
            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                onClick={clearSrsText}
                disabled={!srsText}
              >
                Clear
              </Button>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="text-primary-600 border-primary-600 hover:bg-primary-50"
                  >
                    Choose Template
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">AI-Generated Templates</h4>
                    <p className="text-xs text-gray-500">Select a pre-built template to use</p>
                    <div className="grid gap-2 pt-2">
                      {templateOptions.map((template, index) => (
                        <Button 
                          key={index} 
                          variant="ghost" 
                          className={`justify-start text-left h-auto py-2 ${selectedTemplate === index ? 'bg-blue-50 text-blue-700' : ''}`}
                          onClick={() => useTemplate(index)}
                        >
                          <div>
                            <p className="font-medium text-sm">{template.name}</p>
                            <p className="text-xs text-gray-500 truncate">
                              {template.requirements.split('\n').slice(0, 2).join(', ')}...
                            </p>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {selectedTemplate !== null && (
              <div className="flex items-center p-2 bg-blue-50 rounded border border-blue-100 text-xs">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                  <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
                <span className="text-blue-700">Using {templateOptions[selectedTemplate].name}</span>
              </div>
            )}
          </div>
          
          <div className="text-xs text-gray-500 mt-2">
            <p className="font-medium">Format Tips:</p>
            <ul className="list-disc list-inside">
              <li>Enter each requirement on a new line</li>
              <li>Use ID-XXX: format for requirement IDs</li>
              <li>Be specific about UI elements needed</li>
            </ul>
          </div>
        </TabsContent>
        
        <TabsContent value="file">
          <div className="flex flex-col items-center justify-center h-48 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 p-6">
            {fileName ? (
              <div className="text-center">
                <Badge variant="outline" className="mb-2 bg-green-50 text-green-700 border-green-200">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-3 h-3 mr-1"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                  </svg>
                  File Selected
                </Badge>
                <p className="font-medium text-sm">{fileName}</p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="mt-2 text-xs text-red-600"
                  onClick={clearSrsText}
                >
                  Remove
                </Button>
              </div>
            ) : (
              <>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-10 h-10 text-gray-400 mb-3"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="17 8 12 3 7 8" />
                  <line x1="12" y1="3" x2="12" y2="15" />
                </svg>
                <p className="mb-2 text-sm text-gray-700">
                  <span className="font-medium">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-gray-500">
                  PDF, DOC, DOCX, TXT or MD files
                </p>
                <label className="mt-4 cursor-pointer">
                  <Button variant="default" size="sm">Select File</Button>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept=".doc,.docx,.pdf,.txt,.md"
                    onChange={handleFileChange}
                  />
                </label>
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SRSUploader;
