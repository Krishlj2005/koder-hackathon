import { FC } from 'react';
import { Link, useLocation } from 'wouter';

const Sidebar: FC = () => {
  const [location] = useLocation();

  return (
    <aside className="bg-white border-r border-gray-200 w-full md:w-64 flex-shrink-0 overflow-y-auto">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <div className="bg-primary-600 text-white p-2 rounded">
            <i className="fas fa-vial fa-lg"></i>
          </div>
          <h1 className="ml-3 text-xl font-semibold text-gray-800">FigmaTestAI</h1>
        </div>
        <p className="text-xs text-gray-500 mt-1">SRS Testing Platform</p>
      </div>
      
      <nav className="p-4">
        <ul className="space-y-2">
          <li>
            <Link 
              href="/" 
              className={`flex items-center p-2 rounded-md ${
                location === '/' 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-5 h-5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                <polyline points="9 22 9 12 15 12 15 22" />
              </svg>
              <span className="ml-3">Dashboard</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/projects" 
              className={`flex items-center p-2 rounded-md ${
                location === '/projects' 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-5 h-5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" />
                <path d="M13 2v7h7" />
              </svg>
              <span className="ml-3">Projects</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/history" 
              className={`flex items-center p-2 rounded-md ${
                location === '/history' 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-5 h-5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 20v-6M6 20V10M18 20V4" />
              </svg>
              <span className="ml-3">History</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/settings" 
              className={`flex items-center p-2 rounded-md ${
                location === '/settings' 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-5 h-5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                <circle cx="12" cy="12" r="3" />
              </svg>
              <span className="ml-3">Settings</span>
            </Link>
          </li>
        </ul>
      </nav>
      
      <div className="p-4 mt-4 border-t border-gray-200">
        <h3 className="text-sm font-medium text-gray-500 uppercase">Recent Projects</h3>
        <ul className="mt-2 space-y-1">
          <li>
            <Link href="/" className="block px-2 py-1 text-sm rounded hover:bg-gray-100">
              E-Commerce App
            </Link>
          </li>
          <li>
            <Link href="/" className="block px-2 py-1 text-sm rounded hover:bg-gray-100">
              Health Dashboard
            </Link>
          </li>
          <li>
            <Link href="/" className="block px-2 py-1 text-sm rounded hover:bg-gray-100">
              Travel Booking UI
            </Link>
          </li>
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;
