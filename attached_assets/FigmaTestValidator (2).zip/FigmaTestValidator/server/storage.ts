import { 
  users, type User, type InsertUser,
  projects, type Project, type InsertProject,
  tests, type Test, type InsertTest,
  requirements, type Requirement, type InsertRequirement
} from "@shared/schema";

export interface IStorage {
  // User methods (kept from original)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Project methods
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: number): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  
  // Test methods
  createTest(test: InsertTest): Promise<Test>;
  getTest(id: number): Promise<Test | undefined>;
  getTestsByProject(projectId: number): Promise<Test[]>;
  getAllTests(): Promise<Test[]>;
  updateTestStatus(id: number, status: string, progress: number): Promise<Test>;
  updateTestResults(
    id: number, 
    passRate: number, 
    totalRequirements: number, 
    passedRequirements: number, 
    partialRequirements: number,
    failedRequirements: number
  ): Promise<Test>;
  updateTestAutomation(
    id: number,
    framework: string,
    browsers: string[],
    customScript: string | null
  ): Promise<Test>;
  updateTestCICD(
    id: number,
    provider: string,
    webhookUrl: string | null
  ): Promise<Test>;
  
  // Requirement methods
  createRequirement(requirement: InsertRequirement): Promise<Requirement>;
  getRequirementsByTest(testId: number): Promise<Requirement[]>;
  updateRequirementStatus(
    id: number, 
    status: string, 
    confidence: number, 
    figmaElements?: any, 
    missingElements?: any, 
    analysisNotes?: string
  ): Promise<Requirement>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private tests: Map<number, Test>;
  private requirements: Map<number, Requirement>;
  
  private userId: number;
  private projectId: number;
  private testId: number;
  private requirementId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.tests = new Map();
    this.requirements = new Map();
    
    this.userId = 1;
    this.projectId = 1;
    this.testId = 1;
    this.requirementId = 1;
    
    // Initialize with demo data
    this.initializeDemoData();
  }

  // User methods (kept from original)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Project methods
  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.projectId++;
    const project: Project = { 
      ...insertProject, 
      id, 
      createdAt: new Date() 
    };
    this.projects.set(id, project);
    return project;
  }
  
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  // Test methods
  async createTest(insertTest: InsertTest): Promise<Test> {
    const id = this.testId++;
    const test: Test = {
      ...insertTest,
      id,
      status: "pending",
      progress: 0,
      createdAt: new Date(),
      completedAt: null,
      passRate: null,
      totalRequirements: null,
      passedRequirements: null,
      partialRequirements: null,
      failedRequirements: null
    };
    this.tests.set(id, test);
    return test;
  }
  
  async getTest(id: number): Promise<Test | undefined> {
    return this.tests.get(id);
  }
  
  async getTestsByProject(projectId: number): Promise<Test[]> {
    return Array.from(this.tests.values())
      .filter(test => test.projectId === projectId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getAllTests(): Promise<Test[]> {
    return Array.from(this.tests.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async updateTestStatus(id: number, status: string, progress: number): Promise<Test> {
    const test = this.tests.get(id);
    if (!test) throw new Error(`Test with id ${id} not found`);
    
    const updatedTest: Test = {
      ...test,
      status,
      progress,
      completedAt: status === "completed" ? new Date() : test.completedAt
    };
    
    this.tests.set(id, updatedTest);
    return updatedTest;
  }
  
  async updateTestResults(
    id: number, 
    passRate: number, 
    totalRequirements: number, 
    passedRequirements: number, 
    partialRequirements: number,
    failedRequirements: number
  ): Promise<Test> {
    const test = this.tests.get(id);
    if (!test) throw new Error(`Test with id ${id} not found`);
    
    const updatedTest: Test = {
      ...test,
      passRate,
      totalRequirements,
      passedRequirements,
      partialRequirements,
      failedRequirements,
      status: "completed",
      progress: 100,
      completedAt: new Date()
    };
    
    this.tests.set(id, updatedTest);
    return updatedTest;
  }
  
  async updateTestAutomation(
    id: number,
    framework: string,
    browsers: string[],
    customScript: string | null
  ): Promise<Test> {
    const test = this.tests.get(id);
    if (!test) throw new Error(`Test with id ${id} not found`);
    
    // In a real implementation, we would store the automation configuration
    // For now, we'll just update the test with a flag to show it has automation
    const updatedTest: Test = {
      ...test,
      automationFramework: framework as any, // We'd need to add this to the schema in a real app
      automationBrowsers: browsers as any,   // We'd need to add this to the schema in a real app
      hasAutomation: true as any             // We'd need to add this to the schema in a real app
    };
    
    this.tests.set(id, updatedTest);
    return updatedTest;
  }
  
  async updateTestCICD(
    id: number,
    provider: string,
    webhookUrl: string | null
  ): Promise<Test> {
    const test = this.tests.get(id);
    if (!test) throw new Error(`Test with id ${id} not found`);
    
    // In a real implementation, we would store the CI/CD configuration
    // For now, we'll just update the test with a flag to show it has CI/CD integration
    const updatedTest: Test = {
      ...test,
      cicdProvider: provider as any,       // We'd need to add this to the schema in a real app
      cicdWebhookUrl: webhookUrl as any,   // We'd need to add this to the schema in a real app
      hasCICD: true as any                 // We'd need to add this to the schema in a real app
    };
    
    this.tests.set(id, updatedTest);
    return updatedTest;
  }
  
  // Requirement methods
  async createRequirement(insertRequirement: InsertRequirement): Promise<Requirement> {
    const id = this.requirementId++;
    const requirement: Requirement = {
      ...insertRequirement,
      id,
      status: "pending",
      confidence: 0,
      figmaElements: null,
      missingElements: null,
      analysisNotes: null
    };
    this.requirements.set(id, requirement);
    return requirement;
  }
  
  async getRequirementsByTest(testId: number): Promise<Requirement[]> {
    return Array.from(this.requirements.values())
      .filter(req => req.testId === testId);
  }
  
  async updateRequirementStatus(
    id: number, 
    status: string, 
    confidence: number, 
    figmaElements?: any, 
    missingElements?: any, 
    analysisNotes?: string
  ): Promise<Requirement> {
    const requirement = this.requirements.get(id);
    if (!requirement) throw new Error(`Requirement with id ${id} not found`);
    
    const updatedRequirement: Requirement = {
      ...requirement,
      status,
      confidence,
      figmaElements: figmaElements || requirement.figmaElements,
      missingElements: missingElements || requirement.missingElements,
      analysisNotes: analysisNotes || requirement.analysisNotes
    };
    
    this.requirements.set(id, updatedRequirement);
    return updatedRequirement;
  }

  // Initialize with demo data for UI testing
  private initializeDemoData() {
    // Projects
    const ecommerceProject = this.createProject({ name: "E-Commerce App Redesign" });
    const healthProject = this.createProject({ name: "Health Dashboard UI" });
    const travelProject = this.createProject({ name: "Travel Booking App" });
    
    // Make these promises execute synchronously for initialization
    ecommerceProject.then(project => {
      // E-Commerce App Redesign test has been removed as it wasn't working properly
    });
    
    healthProject.then(project => {
      // Create a completed test for Health Dashboard
      this.createTest({
        projectId: project.id,
        name: "Health Dashboard UI",
        figmaUrl: "https://www.figma.com/file/example/health-dashboard",
        figmaFileName: "HealthDashboard.fig"
      }).then(test => {
        // Update test to be completed with results
        this.updateTestResults(
          test.id, 
          84, // pass rate
          45, // total requirements
          38, // passed
          4,  // partial
          3   // failed
        );
        
        // Add requirement examples
        const requirements = [
          {
            code: "SRS-001",
            description: "User dashboard shows health metrics",
            status: "passed",
            confidence: 100,
            figmaElements: [
              "Frame \"Dashboard/Health Metrics\"",
              "Heart rate component",
              "Step counter with daily goal",
              "Sleep tracking panel"
            ],
            missingElements: null,
            analysisNotes: "Found in frame \"Dashboard/Health Metrics\" with 100% confidence"
          },
          {
            code: "SRS-012",
            description: "Settings page with notification preferences",
            status: "partial",
            confidence: 67,
            figmaElements: [
              "Frame \"Settings\" with profile information",
              "Data sharing toggle controls"
            ],
            missingElements: ["Notification preference controls"],
            analysisNotes: "Found in frame \"Settings\" but missing notification controls"
          },
          {
            code: "SRS-023",
            description: "Export data in CSV format",
            status: "failed",
            confidence: 0,
            figmaElements: null,
            missingElements: ["UI elements for data export"],
            analysisNotes: "No matching elements found in design"
          }
        ];
        
        // Add each requirement
        requirements.forEach(req => {
          this.createRequirement({
            testId: test.id,
            code: req.code,
            description: req.description
          }).then(requirement => {
            this.updateRequirementStatus(
              requirement.id,
              req.status,
              req.confidence,
              req.figmaElements,
              req.missingElements,
              req.analysisNotes
            );
          });
        });
      });
    });
    
    travelProject.then(project => {
      // Create a completed test for Travel Booking
      this.createTest({
        projectId: project.id,
        name: "Travel Booking App",
        figmaUrl: "https://www.figma.com/file/example/travel-booking",
        figmaFileName: "TravelBooking.fig"
      }).then(test => {
        // Update test to be completed with results
        this.updateTestResults(
          test.id, 
          87, // pass rate
          60, // total requirements
          52, // passed
          5,  // partial
          3   // failed
        );
      });
    });
  }
}

export const storage = new MemStorage();
