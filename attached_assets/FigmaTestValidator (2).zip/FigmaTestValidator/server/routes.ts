import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertProjectSchema, 
  insertTestSchema, 
  insertRequirementSchema,
  createTestWithRequirementsSchema
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  // Projects
  app.get("/api/projects", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post("/api/projects", async (req: Request, res: Response) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Error creating project:", error);
        res.status(500).json({ message: "Failed to create project" });
      }
    }
  });

  app.get("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  // Tests
  app.get("/api/tests", async (req: Request, res: Response) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      
      if (projectId) {
        const tests = await storage.getTestsByProject(projectId);
        res.json(tests);
      } else {
        const tests = await storage.getAllTests();
        res.json(tests);
      }
    } catch (error) {
      console.error("Error fetching tests:", error);
      res.status(500).json({ message: "Failed to fetch tests" });
    }
  });

  app.post("/api/tests", async (req: Request, res: Response) => {
    try {
      const validatedData = insertTestSchema.parse(req.body);
      const test = await storage.createTest(validatedData);
      res.status(201).json(test);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Error creating test:", error);
        res.status(500).json({ message: "Failed to create test" });
      }
    }
  });

  app.get("/api/tests/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getTest(id);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      res.json(test);
    } catch (error) {
      console.error("Error fetching test:", error);
      res.status(500).json({ message: "Failed to fetch test" });
    }
  });

  app.post("/api/tests/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status, progress } = req.body;
      
      // Validate inputs
      if (!status || progress === undefined) {
        return res.status(400).json({ message: "Status and progress are required" });
      }

      const updatedTest = await storage.updateTestStatus(id, status, progress);
      res.json(updatedTest);
    } catch (error) {
      console.error("Error updating test status:", error);
      res.status(500).json({ message: "Failed to update test status" });
    }
  });

  app.post("/api/tests/:id/results", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { 
        passRate, 
        totalRequirements, 
        passedRequirements, 
        partialRequirements, 
        failedRequirements 
      } = req.body;
      
      // Validate inputs
      if (!passRate || !totalRequirements || !passedRequirements || 
          !partialRequirements || !failedRequirements) {
        return res.status(400).json({ message: "All result metrics are required" });
      }

      const updatedTest = await storage.updateTestResults(
        id, 
        passRate, 
        totalRequirements, 
        passedRequirements, 
        partialRequirements, 
        failedRequirements
      );
      res.json(updatedTest);
    } catch (error) {
      console.error("Error updating test results:", error);
      res.status(500).json({ message: "Failed to update test results" });
    }
  });
  
  // Requirements
  app.get("/api/tests/:testId/requirements", async (req: Request, res: Response) => {
    try {
      const testId = parseInt(req.params.testId);
      const requirements = await storage.getRequirementsByTest(testId);
      res.json(requirements);
    } catch (error) {
      console.error("Error fetching requirements:", error);
      res.status(500).json({ message: "Failed to fetch requirements" });
    }
  });

  app.post("/api/requirements", async (req: Request, res: Response) => {
    try {
      const validatedData = insertRequirementSchema.parse(req.body);
      const requirement = await storage.createRequirement(validatedData);
      res.status(201).json(requirement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Error creating requirement:", error);
        res.status(500).json({ message: "Failed to create requirement" });
      }
    }
  });

  app.post("/api/requirements/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { 
        status, 
        confidence, 
        figmaElements, 
        missingElements, 
        analysisNotes 
      } = req.body;
      
      // Validate status and confidence
      if (!status || confidence === undefined) {
        return res.status(400).json({ message: "Status and confidence are required" });
      }

      const updatedRequirement = await storage.updateRequirementStatus(
        id, 
        status, 
        confidence, 
        figmaElements, 
        missingElements, 
        analysisNotes
      );
      res.json(updatedRequirement);
    } catch (error) {
      console.error("Error updating requirement status:", error);
      res.status(500).json({ message: "Failed to update requirement status" });
    }
  });

  // Create test with SRS requirements
  app.post("/api/create-test", async (req: Request, res: Response) => {
    try {
      const { name, figmaUrl, srsText } = req.body;
      
      try {
        // Validate data
        createTestWithRequirementsSchema.parse(req.body);
      } catch (validationError) {
        if (validationError instanceof z.ZodError) {
          return res.status(400).json({ 
            message: fromZodError(validationError).message 
          });
        }
        throw validationError;
      }
      
      // Create a default project if needed (can be improved in real implementation)
      const projects = await storage.getProjects();
      const projectId = projects.length > 0 ? projects[0].id : 
        (await storage.createProject({ name: "Default Project" })).id;
      
      // Create the test
      const test = await storage.createTest({
        projectId,
        name,
        figmaUrl,
        figmaFileName: figmaUrl ? new URL(figmaUrl).pathname.split('/').pop() || "figma-file" : undefined
      });
      
      // Process SRS text if provided (improved implementation)
      if (srsText) {
        // Process requirements - handle different formats (numbered lists, bullet points, etc.)
        let requirementTexts: string[] = [];
        
        // Split by new lines and clean up
        const lines = srsText.split('\n').filter((line: string) => line.trim());
        
        // Process each line, looking for requirement patterns
        for (let i = 0; i < lines.length; i++) {
          let line: string = lines[i].trim();
          
          // Remove common list prefixes (numbers, bullet points, etc.)
          line = line.replace(/^(\d+\.|\*|\-|\•|\[\s*\]|\[\s*x\s*\])\s*/, '');
          
          // Skip very short lines that are likely headers
          if (line.length < 5) continue;
          
          // If it starts with "requirement" or "REQ" but doesn't end with punctuation, 
          // it might be a header - check the next line
          if (/^(requirement|req)/i.test(line) && !/[.!?]$/.test(line) && i+1 < lines.length) {
            requirementTexts.push(line + ": " + lines[i+1].trim());
            i++; // Skip the next line as we've incorporated it
          } else {
            requirementTexts.push(line);
          }
        }
        
        // Create requirement objects
        const requirements = requirementTexts.map((text, index) => {
          return {
            testId: test.id,
            code: `SRS-${String(index + 1).padStart(3, '0')}`,
            description: text
          };
        });
        
        // Create requirements
        for (const req of requirements) {
          await storage.createRequirement(req);
        }
        
        // Start the test (in a real app, this would trigger actual processing)
        await storage.updateTestStatus(test.id, "in-progress", 10);
        
        // Simulate progress after a short delay
        setTimeout(async () => {
          try {
            await storage.updateTestStatus(test.id, "in-progress", 30);
          } catch (error) {
            console.error("Error updating test status:", error);
          }
        }, 1000);
      }
      
      res.status(201).json({
        message: "Test created successfully",
        testId: test.id
      });
    } catch (error) {
      console.error("Error creating test with requirements:", error);
      res.status(500).json({ message: "Failed to create test with requirements" });
    }
  });

  // Simulate test progress (for demo purposes)
  app.post("/api/simulate-test/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getTest(id);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Update test to be completed
      const requirements = await storage.getRequirementsByTest(id);
      const totalRequirements = requirements.length;
      
      // Generate random results
      const passedRequirements = Math.floor(totalRequirements * 0.8);
      const partialRequirements = Math.floor(totalRequirements * 0.1);
      const failedRequirements = totalRequirements - passedRequirements - partialRequirements;
      const passRate = Math.round((passedRequirements + (partialRequirements * 0.5)) / totalRequirements * 100);
      
      const updatedTest = await storage.updateTestResults(
        id,
        passRate,
        totalRequirements,
        passedRequirements,
        partialRequirements,
        failedRequirements
      );
      
      // Update requirements with random statuses
      for (let i = 0; i < requirements.length; i++) {
        let status;
        let confidence;
        
        if (i < passedRequirements) {
          status = "passed";
          confidence = Math.floor(Math.random() * 20) + 80; // 80-100
        } else if (i < passedRequirements + partialRequirements) {
          status = "partial";
          confidence = Math.floor(Math.random() * 30) + 40; // 40-70
        } else {
          status = "failed";
          confidence = Math.floor(Math.random() * 40); // 0-40
        }
        
        // Generate more realistic analysis data
        const figmaElements = [];
        const missingElements = [];
        
        // Add detailed UI element findings based on the requirement description
        if (status === "passed" || status === "partial") {
          const reqDescription = requirements[i].description.toLowerCase();
          if (reqDescription.includes("button")) {
            figmaElements.push("Button component found");
          }
          if (reqDescription.includes("login") || reqDescription.includes("sign in")) {
            figmaElements.push("Login form component found");
          }
          if (reqDescription.includes("dashboard")) {
            figmaElements.push("Dashboard layout found");
          }
          if (reqDescription.includes("menu") || reqDescription.includes("navigation")) {
            figmaElements.push("Navigation menu found");
          }
          if (reqDescription.includes("user") || reqDescription.includes("profile")) {
            figmaElements.push("User profile component found");
          }
          if (reqDescription.includes("search")) {
            figmaElements.push("Search input component found");
          }
          if (reqDescription.includes("form")) {
            figmaElements.push("Form component found");
          }
          if (reqDescription.includes("notification")) {
            figmaElements.push("Notification component found");
          }
          
          // If we didn't find any specific elements, add a generic one
          if (figmaElements.length === 0) {
            figmaElements.push(`Component matching "${requirements[i].description.substring(0, 30)}..." found`);
          }
        }
        
        if (status === "partial" || status === "failed") {
          // Add missing elements based on requirement description
          const reqDescription = requirements[i].description.toLowerCase();
          if (reqDescription.includes("animation") || reqDescription.includes("transition")) {
            missingElements.push("Animation/transition specification missing");
          }
          if (reqDescription.includes("accessibility") || reqDescription.includes("a11y")) {
            missingElements.push("Accessibility labels missing");
          }
          if (reqDescription.includes("responsive") || reqDescription.includes("mobile")) {
            missingElements.push("Mobile responsive design missing");
          }
          if (reqDescription.includes("dark mode") || reqDescription.includes("theme")) {
            missingElements.push("Dark mode variant missing");
          }
          if (reqDescription.includes("error") || reqDescription.includes("validation")) {
            missingElements.push("Error state visuals missing");
          }
          
          // If we didn't find any specific missing elements, add a generic one
          if (missingElements.length === 0 && status === "failed") {
            missingElements.push(`No visual elements found for "${requirements[i].description.substring(0, 30)}..."`);
          } else if (missingElements.length === 0 && status === "partial") {
            missingElements.push("Implementation is incomplete");
          }
        }
        
        // Generate detailed analysis notes
        let analysisNotes = `Analysis performed with ${confidence}% confidence. `;
        
        if (status === "passed") {
          analysisNotes += "All requirements are fully implemented in the design.";
        } else if (status === "partial") {
          analysisNotes += "The requirement is partially implemented. Some elements are missing or incomplete.";
        } else {
          analysisNotes += "The requirement is not implemented in the design. Recommend adding the necessary UI elements.";
        }
        
        await storage.updateRequirementStatus(
          requirements[i].id,
          status,
          confidence,
          figmaElements.length > 0 ? figmaElements : null,
          missingElements.length > 0 ? missingElements : null,
          analysisNotes
        );
      }
      
      res.json({
        message: "Test simulation completed",
        test: updatedTest
      });
    } catch (error) {
      console.error("Error simulating test:", error);
      res.status(500).json({ message: "Failed to simulate test" });
    }
  });

  // New endpoints for test automation and CI/CD integration
  
  // Generate automated tests for a specific test
  app.post("/api/tests/:id/generate-automation", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getTest(id);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Validate request data
      const automationSchema = z.object({
        framework: z.enum(["playwright", "cypress", "selenium"]),
        browsers: z.array(z.string()).min(1),
        customScript: z.union([z.string(), z.null(), z.undefined()]).optional()
      });
      
      const validatedData = automationSchema.parse(req.body);
      
      // Get requirements for this test to create more accurate tests
      const requirements = await storage.getRequirementsByTest(id);
      
      // In a real implementation, this would generate actual test scripts
      // For now, we'll simulate success by updating the test status
      const updatedTest = await storage.updateTestAutomation(
        id,
        validatedData.framework,
        validatedData.browsers,
        validatedData.customScript || null
      );
      
      // Generate sample test file content based on the framework
      let sampleTestCode = "";
      
      if (validatedData.framework === "playwright") {
        sampleTestCode = `
import { test, expect } from '@playwright/test';

test('Design validation test for ${test.name}', async ({ page }) => {
  // Navigate to the application page
  await page.goto('https://your-application-url.com');
  
  // Test key requirements from the SRS document
  // Requirement: User dashboard shows health metrics
  const healthMetrics = await page.locator('.health-metrics-container');
  await expect(healthMetrics).toBeVisible();
  
  // Check for specific UI elements mentioned in requirements
  const heartRate = await page.locator('.heart-rate');
  await expect(heartRate).toBeVisible();
  
  // Validate layout matches Figma design
  const dimensions = await healthMetrics.boundingBox();
  expect(dimensions.width).toBeGreaterThan(300);
  
  // Take a screenshot for visual comparison
  await page.screenshot({ path: 'design-validation.png' });
});`;
      } else if (validatedData.framework === "cypress") {
        sampleTestCode = `
describe('Design validation test for ${test.name}', () => {
  it('Should match design requirements from SRS', () => {
    // Visit the application
    cy.visit('https://your-application-url.com');
    
    // Test key requirements from the SRS document
    // Requirement: User dashboard shows health metrics
    cy.get('.health-metrics-container').should('be.visible');
    
    // Check for specific UI elements mentioned in requirements
    cy.get('.heart-rate').should('be.visible');
    
    // Validate layout matches Figma design
    cy.get('.health-metrics-container').then($el => {
      expect($el.width()).to.be.greaterThan(300);
    });
    
    // Take a screenshot for visual comparison
    cy.screenshot('design-validation');
  });
});`;
      } else {
        sampleTestCode = `
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Test;
import static org.junit.Assert.*;

public class DesignValidationTest {
  @Test
  public void testDesignValidation() {
    WebDriver driver = new ChromeDriver();
    driver.get("https://your-application-url.com");
    
    // Test key requirements from the SRS document
    // Requirement: User dashboard shows health metrics
    WebElement healthMetrics = driver.findElement(By.className("health-metrics-container"));
    assertTrue(healthMetrics.isDisplayed());
    
    // Check for specific UI elements mentioned in requirements
    WebElement heartRate = driver.findElement(By.className("heart-rate"));
    assertTrue(heartRate.isDisplayed());
    
    // Validate layout matches Figma design
    int width = healthMetrics.getSize().getWidth();
    assertTrue(width > 300);
    
    driver.quit();
  }
}`;
      }
      
      res.status(200).json({
        message: "Automated tests generated successfully",
        test: updatedTest,
        testCode: sampleTestCode
      });
    } catch (error) {
      console.error("Error generating automated tests:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid request data",
          errors: fromZodError(error).details
        });
      }
      res.status(500).json({ message: "Failed to generate automated tests" });
    }
  });
  
  // Setup CI/CD integration for a test
  app.post("/api/tests/:id/setup-cicd", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getTest(id);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Validate request data
      const cicdSchema = z.object({
        provider: z.enum(["github", "gitlab", "jenkins", "circleci", "travis"]),
        webhookUrl: z.union([z.string(), z.null(), z.undefined()]).optional()
      });
      
      const validatedData = cicdSchema.parse(req.body);
      
      // In a real implementation, this would generate CI/CD configuration files
      // For now, we'll simulate success by updating the test
      const updatedTest = await storage.updateTestCICD(
        id,
        validatedData.provider,
        validatedData.webhookUrl || null
      );
      
      // Generate sample CI/CD configuration based on the provider
      let configFile = "";
      let configFileName = "";
      
      if (validatedData.provider === "github") {
        configFileName = ".github/workflows/design-validation.yml";
        configFile = `name: Design Validation Tests

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  design-validation:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '16'
      - name: Install dependencies
        run: npm ci
      - name: Install Playwright
        run: npx playwright install --with-deps
      - name: Run design validation tests
        run: npm run test:design-validation
      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v2
        with:
          name: design-validation-results
          path: design-validation-results/`;
      } else if (validatedData.provider === "gitlab") {
        configFileName = ".gitlab-ci.yml";
        configFile = `stages:
  - test

design-validation:
  stage: test
  image: mcr.microsoft.com/playwright:v1.32.0-focal
  script:
    - npm ci
    - npm run test:design-validation
  artifacts:
    paths:
      - design-validation-results/
    when: always`;
      } else if (validatedData.provider === "jenkins") {
        configFileName = "Jenkinsfile";
        configFile = `pipeline {
    agent {
        docker {
            image 'mcr.microsoft.com/playwright:v1.32.0-focal'
        }
    }
    stages {
        stage('Setup') {
            steps {
                sh 'npm ci'
            }
        }
        stage('Design Validation Tests') {
            steps {
                sh 'npm run test:design-validation'
            }
        }
    }
    post {
        always {
            archiveArtifacts artifacts: 'design-validation-results/**/*', allowEmptyArchive: true
        }
    }
}`;
      } else if (validatedData.provider === "circleci") {
        configFileName = ".circleci/config.yml";
        configFile = `version: 2.1
orbs:
  node: circleci/node@5.0.2
jobs:
  design-validation:
    docker:
      - image: mcr.microsoft.com/playwright:v1.32.0-focal
    steps:
      - checkout
      - node/install-packages
      - run:
          name: Run design validation tests
          command: npm run test:design-validation
      - store_artifacts:
          path: design-validation-results/
workflows:
  version: 2
  test:
    jobs:
      - design-validation`;
      } else {
        configFileName = ".travis.yml";
        configFile = `language: node_js
node_js:
  - 16
addons:
  apt:
    packages:
      - libgbm-dev
services:
  - xvfb
before_install:
  - npx playwright install-deps
install:
  - npm ci
  - npx playwright install
script:
  - npm run test:design-validation`;
      }
      
      res.status(200).json({
        message: "CI/CD integration setup successfully",
        test: updatedTest,
        configFile: {
          name: configFileName,
          content: configFile
        }
      });
    } catch (error) {
      console.error("Error setting up CI/CD integration:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid request data",
          errors: fromZodError(error).details
        });
      }
      res.status(500).json({ message: "Failed to setup CI/CD integration" });
    }
  });
  
  // Generate comprehensive test report
  app.post("/api/tests/:id/generate-report", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const test = await storage.getTest(id);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Validate request data
      const reportSchema = z.object({
        format: z.enum(["pdf", "html", "xlsx", "json"])
      });
      
      const validatedData = reportSchema.parse(req.body);
      
      // Get test requirements for report content
      const requirements = await storage.getRequirementsByTest(id);
      
      // In a real implementation, this would generate an actual report file
      // For now, we'll simulate success
      const reportUrl = `/api/reports/${test.id}_${Date.now()}.${validatedData.format}`;
      
      res.status(200).json({
        message: "Report generated successfully",
        reportUrl: reportUrl,
        format: validatedData.format,
        reportData: {
          testName: test.name,
          testId: test.id,
          totalRequirements: test.totalRequirements,
          passRate: test.passRate,
          requirementsSummary: {
            passed: test.passedRequirements,
            partial: test.partialRequirements,
            failed: test.failedRequirements
          },
          figmaUrl: test.figmaUrl,
          figmaFileName: test.figmaFileName,
          generatedAt: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error("Error generating report:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid request data",
          errors: fromZodError(error).details
        });
      }
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
