import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model - kept from original
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Project model
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Test model
export const tests = pgTable("tests", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  name: text("name").notNull(),
  figmaUrl: text("figma_url"),
  figmaFileName: text("figma_file_name"),
  status: text("status").notNull().default("pending"), // pending, in-progress, completed
  progress: integer("progress").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  passRate: integer("pass_rate"),
  totalRequirements: integer("total_requirements"),
  passedRequirements: integer("passed_requirements"),
  partialRequirements: integer("partial_requirements"),
  failedRequirements: integer("failed_requirements"),
});

export const insertTestSchema = createInsertSchema(tests).pick({
  projectId: true,
  name: true,
  figmaUrl: true,
  figmaFileName: true,
});

export type InsertTest = z.infer<typeof insertTestSchema>;
export type Test = typeof tests.$inferSelect;

// SRS Requirement model
export const requirements = pgTable("requirements", {
  id: serial("id").primaryKey(),
  testId: integer("test_id").references(() => tests.id),
  code: text("code"), // e.g., SRS-001
  description: text("description").notNull(),
  status: text("status").default("pending"), // pending, passed, partial, failed
  confidence: integer("confidence").default(0), // 0-100
  figmaElements: jsonb("figma_elements"),
  missingElements: jsonb("missing_elements"),
  analysisNotes: text("analysis_notes"),
});

export const insertRequirementSchema = createInsertSchema(requirements).pick({
  testId: true,
  code: true,
  description: true,
});

export type InsertRequirement = z.infer<typeof insertRequirementSchema>;
export type Requirement = typeof requirements.$inferSelect;

// For uploading and creating tests
export const createTestWithRequirementsSchema = z.object({
  name: z.string().min(1, "Project name is required"),
  figmaUrl: z.string().url("Valid Figma URL is required").optional(),
  figmaFile: z.any().optional(),
  srsText: z.string().optional(),
  srsFile: z.any().optional(),
});

export type CreateTestWithRequirements = z.infer<typeof createTestWithRequirementsSchema>;
