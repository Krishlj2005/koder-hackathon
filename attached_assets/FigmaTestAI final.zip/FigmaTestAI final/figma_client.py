import os
import logging
import requests
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

class FigmaClient:
    """Client for interacting with the Figma API."""
    
    def __init__(self, personal_access_token: Optional[str] = None):
        """
        Initialize the Figma client.
        
        Args:
            personal_access_token: Figma Personal Access Token for API authentication.
                                  If not provided, it will try to get it from the FIGMA_ACCESS_TOKEN env var.
                                  Can be None if only using demo mode.
        """
        self.personal_access_token = personal_access_token or os.environ.get("FIGMA_ACCESS_TOKEN")
        self.base_url = "https://api.figma.com/v1"
        
        # Only set up headers if we have a token
        if self.personal_access_token:
            self.headers = {
                "X-Figma-Token": self.personal_access_token,
                "Content-Type": "application/json"
            }
        else:
            self.headers = {"Content-Type": "application/json"}
            logger.warning("No Figma Personal Access Token provided. Only demo mode will be available.")
    
    def get_file(self, file_key: str, use_demo_data: bool = False) -> Dict[str, Any]:
        """
        Get a Figma file.
        
        Args:
            file_key: The Figma file key (found in the URL of the Figma file)
            use_demo_data: If True, return demo data instead of making an API call
        
        Returns:
            Dict containing the Figma file data
        
        Raises:
            Exception: If the request fails
        """
        # If demo mode is enabled or we have no token, return demo data
        if use_demo_data or not self.personal_access_token or file_key.startswith('demo-'):
            logger.info(f"Using demo data for Figma file: {file_key}")
            return self._get_demo_file_data()
        
        # Extract file key from URL if a full URL was provided
        if file_key.startswith('http'):
            # Extract the file key from URLs like https://www.figma.com/file/KEY/name
            parts = file_key.split('/')
            if 'figma.com/file' in file_key and len(parts) >= 5:
                file_key = parts[4]
                logger.info(f"Extracted file key from URL: {file_key}")
            else:
                raise Exception("Invalid Figma URL format. Expected: https://www.figma.com/file/KEY/name")
                
        url = f"{self.base_url}/files/{file_key}"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching Figma file: {str(e)}")
            
            # If the request fails, try falling back to demo data
            if "401" in str(e) or "403" in str(e):
                logger.warning("Authentication failed. Using demo data instead.")
                return self._get_demo_file_data()
            else:
                raise Exception(f"Failed to fetch Figma file: {str(e)}")
    
    def _get_demo_file_data(self) -> Dict[str, Any]:
        """
        Return demo Figma file data for testing purposes.
        
        Returns:
            Dict containing sample Figma file data
        """
        return {
            "document": {
                "id": "0:0",
                "name": "Demo Figma Design",
                "type": "DOCUMENT",
                "children": [
                    {
                        "id": "0:1",
                        "name": "Page 1",
                        "type": "CANVAS",
                        "children": [
                            {
                                "id": "1:1",
                                "name": "Login Form",
                                "type": "FRAME",
                                "children": [
                                    {
                                        "id": "1:2",
                                        "name": "Username Input",
                                        "type": "RECTANGLE",
                                        "fills": [{"type": "SOLID", "color": {"r": 1, "g": 1, "b": 1}}]
                                    },
                                    {
                                        "id": "1:3",
                                        "name": "Password Input",
                                        "type": "RECTANGLE",
                                        "fills": [{"type": "SOLID", "color": {"r": 1, "g": 1, "b": 1}}]
                                    },
                                    {
                                        "id": "1:4",
                                        "name": "Login Button",
                                        "type": "RECTANGLE",
                                        "fills": [{"type": "SOLID", "color": {"r": 0.2, "g": 0.4, "b": 0.9}}]
                                    }
                                ]
                            },
                            {
                                "id": "2:1",
                                "name": "Navigation",
                                "type": "FRAME",
                                "children": [
                                    {
                                        "id": "2:2",
                                        "name": "Home Link",
                                        "type": "TEXT",
                                        "characters": "Home"
                                    },
                                    {
                                        "id": "2:3",
                                        "name": "About Link",
                                        "type": "TEXT",
                                        "characters": "About"
                                    },
                                    {
                                        "id": "2:4",
                                        "name": "Contact Link",
                                        "type": "TEXT",
                                        "characters": "Contact"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        }
    
    def get_file_nodes(self, file_key: str, node_ids: List[str]) -> Dict[str, Any]:
        """
        Get specific nodes from a Figma file.
        
        Args:
            file_key: The Figma file key
            node_ids: List of node IDs to fetch
        
        Returns:
            Dict containing the requested nodes
        
        Raises:
            Exception: If the request fails
        """
        url = f"{self.base_url}/files/{file_key}/nodes"
        params = {"ids": ",".join(node_ids)}
        
        try:
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching Figma file nodes: {str(e)}")
            raise Exception(f"Failed to fetch Figma file nodes: {str(e)}")
    
    def get_image_urls(self, file_key: str, node_ids: List[str], format: str = "png", scale: float = 1) -> Dict[str, Any]:
        """
        Get image URLs for Figma nodes.
        
        Args:
            file_key: The Figma file key
            node_ids: List of node IDs to get images for
            format: Image format (png, jpg, svg, pdf)
            scale: Image scale (1 = 1x, 2 = 2x, etc.)
        
        Returns:
            Dict containing image URLs for the requested nodes
        
        Raises:
            Exception: If the request fails
        """
        url = f"{self.base_url}/images/{file_key}"
        params = {
            "ids": ",".join(node_ids),
            "format": format,
            "scale": scale
        }
        
        try:
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching Figma image URLs: {str(e)}")
            raise Exception(f"Failed to fetch Figma image URLs: {str(e)}")
    
    def extract_ui_components(self, figma_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract UI components from Figma file data.
        
        Args:
            figma_data: Figma file data from get_file()
        
        Returns:
            List of UI components with their properties
        """
        components = []
        
        def traverse_node(node, parent_name=""):
            # Skip invisible nodes
            if node.get("visible") is False:
                return
            
            node_name = node.get("name", "")
            full_name = f"{parent_name}/{node_name}" if parent_name else node_name
            
            # Add node to components if it's a UI element
            if node.get("type") in ["FRAME", "GROUP", "COMPONENT", "INSTANCE", "RECTANGLE", "ELLIPSE", "TEXT"]:
                component = {
                    "id": node.get("id", ""),
                    "name": node_name,
                    "full_name": full_name,
                    "type": node.get("type", ""),
                }
                
                # Add text content for text elements
                if node.get("type") == "TEXT" and "characters" in node:
                    component["text"] = node.get("characters", "")
                
                # Add additional properties if available
                if "fills" in node:
                    colors = []
                    for fill in node.get("fills", []):
                        if fill.get("visible", False) and fill.get("type") == "SOLID":
                            color = fill.get("color", {})
                            if color:
                                r = int(color.get("r", 0) * 255)
                                g = int(color.get("g", 0) * 255)
                                b = int(color.get("b", 0) * 255)
                                a = color.get("a", 1)
                                colors.append(f"rgba({r},{g},{b},{a})")
                    
                    if colors:
                        component["colors"] = colors
                
                # Extract properties for potential CSS selectors
                if node.get("name", "").lower().find("button") >= 0:
                    component["element_type"] = "button"
                elif node.get("name", "").lower().find("input") >= 0:
                    component["element_type"] = "input"
                elif node.get("name", "").lower().find("form") >= 0:
                    component["element_type"] = "form"
                elif node.get("type") == "TEXT":
                    if node.get("name", "").lower().find("label") >= 0:
                        component["element_type"] = "label"
                    else:
                        component["element_type"] = "text"
                
                components.append(component)
            
            # Recursively process children
            if "children" in node:
                for child in node.get("children", []):
                    traverse_node(child, full_name)
        
        # Start traversal from document
        if "document" in figma_data:
            traverse_node(figma_data["document"])
        
        return components