import os
import logging
import json
from typing import Dict, List, Any, Optional

import google.generativeai as genai

logger = logging.getLogger(__name__)

class GeminiClient:
    """
    Client for interacting with Google's Gemini AI API.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the Gemini client.
        
        Args:
            api_key: Gemini API key for generating content.
                   If not provided, it will try to get it from the GEMINI_API_KEY env var.
        """
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        self.demo_mode = False
        
        # Try to initialize Gemini client
        if self.api_key:
            try:
                genai.configure(api_key=self.api_key)
                # Try different model names to handle API version differences
                try:
                    self.model = genai.GenerativeModel('gemini-1.5-pro')
                    logger.info("Gemini AI client initialized with gemini-1.5-pro model")
                except Exception:
                    try:
                        self.model = genai.GenerativeModel('gemini-pro')
                        logger.info("Gemini AI client initialized with gemini-pro model")
                    except Exception as e:
                        logger.warning(f"Failed to initialize Gemini model: {str(e)}")
                        self.demo_mode = True
                        return
                logger.info("Gemini AI client initialized successfully")
            except Exception as e:
                logger.warning(f"Failed to initialize Gemini client: {str(e)}. Will use demo mode.")
                self.demo_mode = True
        else:
            logger.warning("No Gemini API key provided. Will use demo mode.")
            self.demo_mode = True
    
    def generate_content(self, prompt: str, response_format: str = None) -> str:
        """
        Generate content from a prompt using Gemini AI.
        
        Args:
            prompt: The prompt to send to Gemini.
            response_format: Optional string indicating desired response format (e.g., 'json').
                            If 'json', the method will try to ensure valid JSON is returned.
        
        Returns:
            Generated content as a string.
        
        Raises:
            Exception: If content generation fails.
        """
        if self.demo_mode:
            logger.info("Using demo mode for Gemini content generation")
            
            # For JSON responses, return a valid JSON string
            if response_format == 'json':
                return '{"status": "demo", "message": "This is a demo response in JSON format"}'
            
            # Return a generic demo response for text
            return "This is a demo response from the Gemini AI client."
        
        try:
            # Append instructions if a specific format is requested
            if response_format == 'json':
                prompt += "\n\nYour response must be a valid JSON object. Do not include any explanations, only the JSON."
            
            # Generate the response from Gemini
            response = self.model.generate_content(prompt)
            
            # Extract the text content 
            content = response.text
            
            # Special handling for JSON format
            if response_format == 'json':
                try:
                    # Validate that the response is valid JSON by parsing it
                    json.loads(content)
                    return content
                except json.JSONDecodeError:
                    # If it's not valid JSON, make a second attempt with clearer instructions
                    retry_prompt = prompt + "\n\nYour previous response was not valid JSON. Please respond with ONLY a valid JSON object. No explanation text."
                    retry_response = self.model.generate_content(retry_prompt)
                    content = retry_response.text
                    
                    # Clean up common issues with JSON formatting
                    content = content.strip()
                    if content.startswith("```json"):
                        content = content.split("```json")[1]
                    if content.endswith("```"):
                        content = content.split("```")[0]
                    content = content.strip()
                    
                    # Validate again
                    try:
                        json.loads(content)
                    except json.JSONDecodeError as e:
                        logger.error(f"Failed to get valid JSON from Gemini after retry: {str(e)}")
                        # Fall back to a simple valid JSON
                        content = '{"error": "Failed to generate valid JSON", "message": "Using fallback response"}'
            
            return content
            
        except Exception as e:
            logger.error(f"Error generating content with Gemini: {str(e)}")
            raise Exception(f"Failed to generate content with Gemini: {str(e)}")
            
    def analyze_image(self, base64_image: str, prompt: str = None) -> str:
        """
        Analyze an image using Gemini's multimodal capabilities.
        
        Args:
            base64_image: The base64-encoded image data.
            prompt: Optional specific instructions for the image analysis.
                   If not provided, a default prompt will be used.
        
        Returns:
            Analysis of the image as a string.
        
        Raises:
            Exception: If image analysis fails.
        """
        if self.demo_mode:
            logger.info("Using demo mode for Gemini image analysis")
            return "This is a demo image analysis response from the Gemini AI client."
            
        try:
            # Use a default prompt if none provided
            if not prompt:
                prompt = "Describe this image in detail. What do you see?"
                
            # Check for model support (Gemini Pro Vision or Gemini 1.5)
            try:
                # Format the parts for multimodal input
                response = self.model.generate_content(
                    contents=[
                        {
                            "role": "user",
                            "parts": [
                                {"text": prompt},
                                {"inline_data": {"mime_type": "image/jpeg", "data": base64_image}}
                            ]
                        }
                    ]
                )
                return response.text
            except Exception as e:
                logger.error(f"Error in Gemini multimodal request format: {str(e)}")
                
                # Try alternate format for different Gemini API versions
                try:
                    response = self.model.generate_content(
                        [prompt, {"image_data": {"mime_type": "image/jpeg", "data": base64_image}}]
                    )
                    return response.text
                except Exception as inner_e:
                    logger.error(f"Alternate Gemini multimodal format also failed: {str(inner_e)}")
                    raise Exception(f"Failed to analyze image with Gemini: {str(e)}. Alternate format error: {str(inner_e)}")
                    
        except Exception as e:
            logger.error(f"Error analyzing image with Gemini: {str(e)}")
            raise Exception(f"Failed to analyze image with Gemini: {str(e)}")
            
    def generate_image(self, prompt: str, size: str = "1024x1024") -> Dict[str, str]:
        """
        Generate an image using Gemini (not directly supported, returns demo result).
        This is a compatibility method for the unified AI client.
        
        Args:
            prompt: The description of the image to generate.
            size: Size of the image.
        
        Returns:
            Dict containing a placeholder URL.
        """
        logger.warning("Image generation not natively supported by Gemini")
        return {"url": "https://via.placeholder.com/1024x1024?text=Not+Supported+By+Gemini"}
        
    def transcribe_audio(self, audio_file_path: str) -> str:
        """
        Transcribe audio (not directly supported, returns demo result).
        This is a compatibility method for the unified AI client.
        
        Args:
            audio_file_path: Path to the audio file.
        
        Returns:
            Demo transcription text.
        """
        logger.warning("Audio transcription not natively supported by Gemini")
        return "Audio transcription is not natively supported by Gemini."