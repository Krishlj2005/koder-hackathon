# Figma Test Platform

An intelligent, AI-powered testing platform that transforms design-to-testing workflows by analyzing Figma designs and automatically generating, executing, and reporting UI tests for web applications.

## 🌟 Features

- **Multi-Model AI Support**: Choose between OpenAI or Google Gemini AI for all AI-powered features
- **Design Analysis**: Extract UI components, interactions, and requirements from Figma designs
- **Automated Test Generation**: Create comprehensive test suites based on design specifications
- **Selenium Test Execution**: Run tests against live web applications with screenshot comparisons
- **CI/CD Integration**: Seamlessly integrate with GitHub Actions for continuous testing
- **Rich Reporting**: Generate detailed reports with AI-powered improvement recommendations
- **Demo Mode**: Try the platform without API keys or in environments with restrictions

## 🚀 Getting Started

### Prerequisites

- Python 3.10 or higher
- Google Gemini API key (optional, for AI features)
- OpenAI API key (optional, alternative AI provider)
- Figma Personal Access Token (optional, for Figma API access)
- GitHub Personal Access Token (optional, for GitHub Actions integration)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/figma-test-platform.git
   cd figma-test-platform
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Create a `.env` file from the template:
   ```bash
   cp .env.example .env
   ```

4. Edit `.env` to add your API keys and configuration:
   - Set `DEMO_MODE=false` to use actual Figma websites
   - Set `SIMULATION_MODE` based on your environment capabilities
   - Add your `FIGMA_ACCESS_TOKEN` for real Figma API access
   - Choose your preferred AI provider by setting either `GEMINI_API_KEY` or `OPENAI_API_KEY`
   - Add `GITHUB_TOKEN` if you want CI/CD integration

5. Start the application:
   ```bash
   python main.py
   ```

### Quick Start with Docker

```bash
docker build -t figma-test-platform .
docker run -p 5000:5000 --env-file .env figma-test-platform
```

## 🔧 Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `SESSION_SECRET` | Secret key for session management | Random string |
| `PORT` | Port to run the application on | 5000 |
| `DEBUG` | Enable debug mode | true |
| `DEMO_MODE` | Run in demo mode without API keys | false |
| `SIMULATION_MODE` | Simulate test execution without browser | auto-detected |
| `LOCAL_DEV` | Enable local development features | false |
| `USE_LOCAL_BOOTSTRAP` | Use local Bootstrap files instead of CDN | false |
| `DATABASE_URL` | Database connection string | sqlite:///instance/figma_test.db |
| `AI_PROVIDER` | AI provider to use (openai, gemini) | auto-detected |
| `GEMINI_API_KEY` | Google Gemini API key (preferred for Replit) | - |
| `OPENAI_API_KEY` | OpenAI API key (with gpt-4o support) | - |
| `FIGMA_ACCESS_TOKEN` | Figma Personal Access Token | - |
| `GITHUB_TOKEN` | GitHub Personal Access Token | - |
| `GITHUB_REPO_OWNER` | GitHub repository owner/organization | - |
| `GITHUB_REPO_NAME` | GitHub repository name | - |
| `HEADLESS` | Run Selenium in headless mode | true |
| `SCREENSHOT_DIR` | Directory to save screenshots | static/screenshots |
| `SELENIUM_TIMEOUT` | Timeout for Selenium operations in seconds | 30 |

## 🛣️ Project Structure

```
figma-test-platform/
├── app.py                  # Core application setup
├── load_env.py             # Environment variable loader
├── main.py                 # Application entry point
├── models.py               # Database models
├── routes.py               # Application routes
├── ai_client.py            # Unified AI client
├── gemini_client.py        # Google Gemini AI client
├── openai_client.py        # OpenAI client
├── figma_client.py         # Figma API client
├── github_actions.py       # GitHub Actions integration
├── selenium_executor.py    # Test execution engine
├── test_generator.py       # Test case generator
├── report_generator.py     # Test report generator
├── templates/              # HTML templates
├── static/                 # Static assets
│   ├── css/                # CSS stylesheets
│   ├── js/                 # JavaScript files
│   └── screenshots/        # Test screenshots
├── instance/               # Instance-specific data
└── tests/                  # Unit and integration tests
```

## 🧪 Operation Modes

### Demo Mode

The platform offers a comprehensive demo mode that allows you to explore its features without requiring API keys or facing environment restrictions. This is particularly useful for:

- Evaluating the platform before obtaining API keys
- Running in environments where Selenium WebDriver execution is restricted
- Testing interface functionality without making actual API calls

To enable demo mode, set `DEMO_MODE=true` in your `.env` file or pass it as an environment variable.

### Production Mode

For full functionality with actual Figma websites, set the following in your `.env` file:

```
DEMO_MODE=false
SIMULATION_MODE=false  # Set to true in environments without Chrome WebDriver
```

When in production mode:
- The application uses real Figma API calls with your `FIGMA_ACCESS_TOKEN`
- Tests are executed against live web applications using Selenium
- Test results include actual screenshots and UI comparisons
- GitHub Actions workflows use real CI/CD pipelines for continuous testing

### Simulation Mode

For environments like Replit where running a full Chrome WebDriver might be challenging:

```
SIMULATION_MODE=true
```

This mode:
- Maintains real Figma API integration
- Simulates test execution without requiring a browser instance
- Provides realistic test results based on AI analysis
- Is automatically enabled when running in Replit but can be manually configured

## 🌐 API Integration

The platform integrates with several external APIs:

- **Figma API**: To extract design specifications and UI components
- **Google Gemini AI / OpenAI**: For generating test plans, recommendations, and analysis
- **GitHub API**: For triggering CI/CD workflows

Refer to the [API Documentation](API.md) for detailed information on API integrations.

## 🔍 Testing

Run the test suite:

```bash
python -m pytest
```

## 🚢 Deployment

### Deploying to Replit

1. Fork this repository on Replit
2. Set up your environment secrets in the Replit Secrets tab:
   - `GEMINI_API_KEY` or `OPENAI_API_KEY` (at least one is recommended)
   - `FIGMA_ACCESS_TOKEN` (for Figma integration)
   - `GITHUB_TOKEN` (for GitHub Actions integration)
   - `SESSION_SECRET` (for secure sessions)

3. Run the application using the Run button or Shell command:
   ```bash
   gunicorn main:app --bind 0.0.0.0:5000
   ```

4. Click on the "Deploy" button in the Replit UI to deploy your application

### Deploying to Other Cloud Platforms

#### Heroku

1. Create a new Heroku app
2. Set up the required environment variables in the Heroku dashboard
3. Deploy using Heroku Git or GitHub integration:
   ```bash
   heroku git:remote -a your-app-name
   git push heroku main
   ```

#### Railway

1. Create a new project on Railway
2. Connect your GitHub repository
3. Set up the environment variables
4. Deploy with automatic updates from your repository

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgements

- [Flask](https://flask.palletsprojects.com/) - Web framework
- [SQLAlchemy](https://www.sqlalchemy.org/) - ORM
- [Selenium](https://www.selenium.dev/) - Browser automation
- [Google Generative AI](https://ai.google.dev/) - AI capabilities
- [OpenAI](https://openai.com/) - Alternative AI provider
- [Bootstrap](https://getbootstrap.com/) - UI framework