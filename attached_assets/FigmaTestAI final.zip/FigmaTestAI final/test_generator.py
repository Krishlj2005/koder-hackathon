import os
import logging
from typing import Dict, List, Any, Optional
import json

from gemini_client import GeminiClient

logger = logging.getLogger(__name__)

class TestGenerator:
    """
    Generates test cases based on Figma design analysis using AI.
    """
    
    def __init__(self, gemini_api_key: Optional[str] = None):
        """
        Initialize the test generator.
        
        Args:
            gemini_api_key: Gemini API key for generating test cases.
                           If not provided, it will try to get it from the GEMINI_API_KEY env var.
        """
        self.demo_mode = False
        
        # Initialize the Gemini client
        try:
            self.gemini_client = GeminiClient(api_key=gemini_api_key)
            self.demo_mode = self.gemini_client.demo_mode
        except Exception as e:
            logger.warning(f"Failed to initialize Gemini client: {str(e)}. Will use demo mode.")
            self.demo_mode = True
    
    def generate_test_cases(self, figma_data: Dict[str, Any], web_url: str) -> List[Dict[str, Any]]:
        """
        Generate test cases based on Figma design analysis.
        
        Args:
            figma_data: Figma file data
            web_url: URL of the web application to test
        
        Returns:
            List of test cases
        """
        # If demo mode is already enabled, use it directly
        if self.demo_mode:
            logger.info("Using demo mode to generate test cases (demo mode already enabled)")
            # Extract UI components from Figma data
            components = self._extract_components(figma_data)
            return self._get_demo_test_cases(components, web_url)
            
        try:
            # Extract UI components from Figma data
            components = self._extract_components(figma_data)
            
            # Create a prompt for the AI
            prompt = f"""
            You are a QA automation expert. Generate comprehensive test cases based on the Figma design components and the web application.
            
            Web Application URL: {web_url}
            
            Figma Design Components:
            {json.dumps(components, indent=2)}
            
            For each component, create appropriate test cases that check:
            1. Presence and visibility
            2. Correct styling and appearance
            3. Functionality and interactions
            4. Any potential edge cases
            
            For form elements, include validation tests.
            For interactive elements like buttons, include action tests.
            For navigation elements, include navigation flow tests.
            
            Format each test case as a JSON object with the following structure:
            {{
                "name": "Test case name",
                "description": "Detailed description of what the test is checking",
                "selector": "CSS selector or XPath to find the element",
                "expected_result": "Expected outcome of the test",
                "element_type": "Type of element being tested (button, input, form, etc.)"
            }}
            
            Return a list of these test case objects, at least 10 test cases.
            """
            
            # Generate content using Gemini
            system_prompt = "You are a QA automation expert that generates test cases in JSON format."
            full_prompt = system_prompt + "\n\n" + prompt
            
            try:
                # Call the Gemini client to generate content
                test_cases_content = self.gemini_client.generate_content(
                    prompt=full_prompt,
                    response_format='json'
                )
                
                try:
                    # Parse the content as JSON
                    test_cases_data = json.loads(test_cases_content)
                    
                    # Ensure the response contains a list of test cases
                    if isinstance(test_cases_data, list):
                        # Direct list response
                        test_cases = test_cases_data
                    elif isinstance(test_cases_data, dict):
                        if "test_cases" in test_cases_data:
                            test_cases = test_cases_data["test_cases"]
                        else:
                            # If the AI didn't use the "test_cases" key, try to find a list in the response
                            list_values = [v for k, v in test_cases_data.items() if isinstance(v, list)]
                            if list_values:
                                test_cases = list_values[0]
                            else:
                                # No list found in the response
                                logger.warning("No test cases list found in Gemini response. Using demo mode.")
                                test_cases = []
                    else:
                        # Unexpected response format
                        logger.warning(f"Unexpected Gemini response format: {type(test_cases_data)}. Using demo mode.")
                        test_cases = []
                    
                    logger.info(f"Generated {len(test_cases)} test cases")
                    return test_cases
                    
                except json.JSONDecodeError as e:
                    # JSON parsing failed, fall back to demo mode
                    logger.error(f"Failed to parse JSON response for test cases: {str(e)}")
                    logger.debug(f"Raw response: {test_cases_content}")
                    logger.warning("Falling back to demo mode due to JSON parsing error")
                    return self._get_demo_test_cases(components, web_url)
                    
            except Exception as e:
                # Gemini API call failed, fall back to demo mode
                logger.warning(f"Gemini API call failed for test case generation: {str(e)}. Falling back to demo mode.")
                return self._get_demo_test_cases(components, web_url)
                
        except Exception as e:
            # Catch any other unexpected errors
            logger.error(f"Unexpected error generating test cases: {str(e)}")
            # Extract components, if possible, and fall back to demo mode
            try:
                components = self._extract_components(figma_data)
                return self._get_demo_test_cases(components, web_url)
            except Exception as inner_e:
                # If component extraction fails too, return a basic set of test cases
                logger.error(f"Failed to extract components for demo mode: {str(inner_e)}")
                return [
                    {
                        "name": "Basic Page Load Test",
                        "description": "Check if the page loads without errors",
                        "selector": "body",
                        "expected_result": "Page should load without errors",
                        "element_type": "page"
                    },
                    {
                        "name": "Page Title Test",
                        "description": "Check if the page has a title",
                        "selector": "title",
                        "expected_result": "Page should have a title",
                        "element_type": "meta"
                    }
                ]
    
    def analyze_missing_elements(self, components: List[Dict[str, Any]], page_type: str) -> List[Dict[str, Any]]:
        """
        Analyze a page to identify missing UI elements based on page type.
        
        Args:
            components: List of UI components
            page_type: Type of page (login, registration, dashboard, etc.)
        
        Returns:
            List of potentially missing elements with recommendations
        """
        logger.info(f"Analyzing missing elements for page type: {page_type}")
        
        # If demo mode is already enabled, use it directly
        if self.demo_mode:
            logger.info("Using demo mode to analyze missing elements (demo mode already enabled)")
            return self._get_demo_missing_elements(components, page_type)
        
        try:
            # Create a prompt for the AI
            prompt = f"""
            You are a UI/UX expert analyzing a web page design. Based on the components present,
            identify potentially missing elements that should be included based on best practices
            for a {page_type} page.
            
            Components found in the design:
            {json.dumps(components, indent=2)}
            
            Analyze the components and identify elements that might be missing based on:
            1. Standard best practices for {page_type} pages
            2. Usability and accessibility requirements
            3. Common user expectations
            
            For each potentially missing element, provide:
            1. Element name/type
            2. Why it should be included
            3. Recommendation for implementation
            
            Format your response as a JSON array of objects with the following fields:
            - "element": The missing element name/type
            - "importance": High/Medium/Low
            - "reason": Why this element is important
            - "recommendation": Suggested implementation approach
            """
            
            # Generate content using Gemini
            system_prompt = "You are a UI/UX expert that identifies missing elements in web designs."
            full_prompt = system_prompt + "\n\n" + prompt
            
            try:
                # Call the Gemini client to generate content
                analysis_content = self.gemini_client.generate_content(
                    prompt=full_prompt,
                    response_format='json'
                )
                
                try:
                    # Parse the content as JSON
                    analysis_data = json.loads(analysis_content)
                    
                    # Ensure the response contains a list of missing elements
                    if isinstance(analysis_data, list):
                        # Direct list response
                        missing_elements = analysis_data
                    elif isinstance(analysis_data, dict):
                        if "missing_elements" in analysis_data:
                            missing_elements = analysis_data["missing_elements"]
                        else:
                            # If the AI didn't use the "missing_elements" key, try to find a list in the response
                            list_values = [v for k, v in analysis_data.items() if isinstance(v, list)]
                            if list_values:
                                missing_elements = list_values[0]
                            else:
                                # No list found in the response
                                logger.warning("No missing elements list found in Gemini response. Using demo mode.")
                                missing_elements = []
                    else:
                        # Unexpected response format
                        logger.warning(f"Unexpected Gemini response format: {type(analysis_data)}. Using demo mode.")
                        missing_elements = []
                    
                    return missing_elements
                    
                except json.JSONDecodeError as e:
                    # JSON parsing failed, fall back to demo mode
                    logger.error(f"Failed to parse JSON response: {str(e)}")
                    logger.debug(f"Raw response: {analysis_content}")
                    logger.warning("Falling back to demo mode due to JSON parsing error")
                    return self._get_demo_missing_elements(components, page_type)
                    
            except Exception as e:
                # Gemini API call failed, fall back to demo mode
                logger.warning(f"Gemini API call failed: {str(e)}. Falling back to demo mode.")
                return self._get_demo_missing_elements(components, page_type)
            
        except Exception as e:
            # Catch any other unexpected errors
            logger.error(f"Unexpected error analyzing missing elements: {str(e)}")
            # Fall back to demo mode if there's an error
            return self._get_demo_missing_elements(components, page_type)
    
    def _extract_components(self, figma_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract UI components from Figma file data."""
        components = []
        
        def traverse_node(node, parent_path=""):
            current_path = parent_path + "/" + node.get("name", "")
            
            # Skip invisible nodes
            if node.get("visible") is False:
                return
            
            # Add node to components if it's a UI element
            if node.get("type") in ["FRAME", "GROUP", "COMPONENT", "INSTANCE", "RECTANGLE", "ELLIPSE", "TEXT"]:
                component = {
                    "id": node.get("id", ""),
                    "name": node.get("name", ""),
                    "type": node.get("type", ""),
                    "path": current_path
                }
                
                # Add text content for text elements
                if node.get("type") == "TEXT" and "characters" in node:
                    component["text"] = node.get("characters", "")
                
                # Add component specific data
                if "fills" in node:
                    component["has_fill"] = any(fill.get("visible", False) for fill in node.get("fills", []))
                
                # Add styles and constraints
                if "style" in node:
                    component["style"] = node.get("style", {})
                
                if "constraints" in node:
                    component["constraints"] = node.get("constraints", {})
                
                components.append(component)
            
            # Recursively process children
            for child in node.get("children", []):
                traverse_node(child, current_path)
        
        # Start traversal from document
        if "document" in figma_data:
            traverse_node(figma_data["document"])
        
        return components
    
    def _get_demo_test_cases(self, components: List[Dict[str, Any]], web_url: str) -> List[Dict[str, Any]]:
        """
        Generate demo test cases based on extracted components.
        
        Args:
            components: List of UI components extracted from Figma
            web_url: URL of the web application to test
            
        Returns:
            List of demo test cases
        """
        logger.info("Generating demo test cases")
        
        # Extract component types to create relevant test cases
        test_cases = []
        
        # Check for login form
        login_form = any("login" in comp.get("name", "").lower() and comp.get("type") == "FRAME" for comp in components)
        
        if login_form:
            test_cases.extend([
                {
                    "name": "Login Form Visibility Test",
                    "description": "Check if the login form is visible on the page",
                    "selector": "form, .login-form, #login-form",
                    "expected_result": "Login form should be visible",
                    "element_type": "form"
                },
                {
                    "name": "Username Input Field Test",
                    "description": "Check if the username/email input field exists and can be interacted with",
                    "selector": "input[type='text'], input[type='email'], input[name='username'], input[name='email']",
                    "expected_result": "Username input field should be visible and accept input",
                    "element_type": "input"
                },
                {
                    "name": "Password Input Field Test",
                    "description": "Check if the password input field exists and can be interacted with",
                    "selector": "input[type='password']",
                    "expected_result": "Password input field should be visible and accept input",
                    "element_type": "input"
                },
                {
                    "name": "Login Button Test",
                    "description": "Check if the login button exists and can be clicked",
                    "selector": "button[type='submit'], input[type='submit'], .login-button, #login-btn",
                    "expected_result": "Login button should be visible and clickable",
                    "element_type": "button"
                },
                {
                    "name": "Login Form Submission Test",
                    "description": "Check if the login form can be submitted with valid credentials",
                    "selector": "form, .login-form, #login-form",
                    "expected_result": "Form should submit successfully and user should be logged in",
                    "element_type": "form"
                }
            ])
        
        # Check for navigation
        navigation = any("nav" in comp.get("name", "").lower() or "menu" in comp.get("name", "").lower() for comp in components)
        
        if navigation:
            test_cases.extend([
                {
                    "name": "Navigation Menu Visibility Test",
                    "description": "Check if the navigation menu is visible on the page",
                    "selector": "nav, .navbar, .navigation, #main-nav",
                    "expected_result": "Navigation menu should be visible",
                    "element_type": "navigation"
                },
                {
                    "name": "Navigation Links Test",
                    "description": "Check if the navigation links are visible and clickable",
                    "selector": "nav a, .navbar a, .nav-link",
                    "expected_result": "Navigation links should be visible and clickable",
                    "element_type": "link"
                },
                {
                    "name": "Active Navigation Item Test",
                    "description": "Check if the active navigation item is correctly highlighted",
                    "selector": "nav a.active, .navbar a.active, .nav-link.active",
                    "expected_result": "Active navigation item should be highlighted",
                    "element_type": "link"
                }
            ])
        
        # Add general page tests
        test_cases.extend([
            {
                "name": "Page Title Test",
                "description": "Check if the page has the correct title",
                "selector": "title",
                "expected_result": "Page title should be correct",
                "element_type": "meta"
            },
            {
                "name": "Page Load Test",
                "description": "Check if the page loads without errors",
                "selector": "body",
                "expected_result": "Page should load without errors",
                "element_type": "page"
            },
            {
                "name": "Responsive Design Test",
                "description": "Check if the page is responsive and adapts to different screen sizes",
                "selector": "body",
                "expected_result": "Page should adapt to different screen sizes",
                "element_type": "page"
            }
        ])
        
        # Ensure we have at least 10 test cases
        if len(test_cases) < 10:
            test_cases.extend([
                {
                    "name": "Page Content Test",
                    "description": "Check if the page content is loaded correctly",
                    "selector": "main, .content, #content",
                    "expected_result": "Page content should be visible",
                    "element_type": "content"
                },
                {
                    "name": "Footer Visibility Test",
                    "description": "Check if the page footer is visible",
                    "selector": "footer, .footer",
                    "expected_result": "Footer should be visible",
                    "element_type": "footer"
                },
                {
                    "name": "Header Visibility Test",
                    "description": "Check if the page header is visible",
                    "selector": "header, .header",
                    "expected_result": "Header should be visible",
                    "element_type": "header"
                },
                {
                    "name": "Images Loading Test",
                    "description": "Check if images on the page load correctly",
                    "selector": "img",
                    "expected_result": "All images should load without errors",
                    "element_type": "image"
                }
            ])
        
        logger.info(f"Generated {len(test_cases)} demo test cases")
        return test_cases
        
    def _get_demo_missing_elements(self, components: List[Dict[str, Any]], page_type: str) -> List[Dict[str, Any]]:
        """
        Generate demo missing elements analysis based on page type.
        
        Args:
            components: List of UI components extracted from Figma
            page_type: Type of page (login, registration, dashboard, etc.)
            
        Returns:
            List of demo missing elements with recommendations
        """
        logger.info(f"Generating demo missing elements analysis for page type: {page_type}")
        
        missing_elements = []
        
        # Convert page_type to lowercase for easier comparison
        page_type = page_type.lower()
        
        # Check for common page elements
        has_header = any("header" in comp.get("name", "").lower() for comp in components)
        has_footer = any("footer" in comp.get("name", "").lower() for comp in components)
        has_navigation = any("nav" in comp.get("name", "").lower() or "menu" in comp.get("name", "").lower() for comp in components)
        
        # Add recommendations based on what's missing
        if not has_header:
            missing_elements.append({
                "element": "Header",
                "importance": "High",
                "reason": "Headers provide branding and context for the page, helping users understand what website they're on.",
                "recommendation": "Add a consistent header with logo, site name, and potentially navigation elements."
            })
        
        if not has_footer:
            missing_elements.append({
                "element": "Footer",
                "importance": "Medium",
                "reason": "Footers provide important links, copyright information, and additional context.",
                "recommendation": "Add a footer with copyright information, links to policies, and possibly contact information."
            })
        
        if not has_navigation:
            missing_elements.append({
                "element": "Navigation Menu",
                "importance": "High",
                "reason": "Navigation menus help users move between different sections of the application.",
                "recommendation": "Add a clear navigation menu with links to the main sections of the application."
            })
        
        # Check for elements based on page type
        if "login" in page_type:
            # Check for login page specific elements
            login_needed_elements = {
                "forgot_password": any("forgot" in comp.get("name", "").lower() or "reset" in comp.get("name", "").lower() for comp in components),
                "remember_me": any("remember" in comp.get("name", "").lower() for comp in components),
                "signup_link": any("sign up" in comp.get("name", "").lower() or "register" in comp.get("name", "").lower() for comp in components)
            }
            
            if not login_needed_elements["forgot_password"]:
                missing_elements.append({
                    "element": "Forgot Password Link",
                    "importance": "High",
                    "reason": "Users often forget their passwords and need a way to reset them. This is a critical usability feature.",
                    "recommendation": "Add a 'Forgot Password' link near the password field that redirects to a password reset page."
                })
            
            if not login_needed_elements["remember_me"]:
                missing_elements.append({
                    "element": "Remember Me Checkbox",
                    "importance": "Medium",
                    "reason": "A remember me option allows users to stay logged in on trusted devices, improving convenience.",
                    "recommendation": "Add a 'Remember me' checkbox below the login form, with default state unchecked."
                })
            
            if not login_needed_elements["signup_link"]:
                missing_elements.append({
                    "element": "Sign Up Link",
                    "importance": "High",
                    "reason": "New users need a clear path to create an account if they don't already have one.",
                    "recommendation": "Add a prominent 'Sign Up' or 'Create Account' link/button near the login form."
                })
                
        elif "dashboard" in page_type:
            # Check for dashboard specific elements
            dashboard_needed_elements = {
                "search": any("search" in comp.get("name", "").lower() for comp in components),
                "notifications": any("notif" in comp.get("name", "").lower() or "alert" in comp.get("name", "").lower() for comp in components),
                "user_profile": any("profile" in comp.get("name", "").lower() or "account" in comp.get("name", "").lower() for comp in components)
            }
            
            if not dashboard_needed_elements["search"]:
                missing_elements.append({
                    "element": "Search Functionality",
                    "importance": "Medium",
                    "reason": "Search helps users quickly find content or features they're looking for, especially in complex dashboards.",
                    "recommendation": "Add a search bar in the header or sidebar for searching content and functionality."
                })
            
            if not dashboard_needed_elements["notifications"]:
                missing_elements.append({
                    "element": "Notifications Panel",
                    "importance": "Medium",
                    "reason": "Notifications keep users informed about system events, updates, or actions they need to take.",
                    "recommendation": "Add a notifications icon in the header with a dropdown panel for displaying notifications."
                })
            
            if not dashboard_needed_elements["user_profile"]:
                missing_elements.append({
                    "element": "User Profile Access",
                    "importance": "High",
                    "reason": "Users need a way to access and manage their profile and account settings.",
                    "recommendation": "Add a user profile dropdown in the header with links to profile, settings, and logout."
                })
                
        elif "registration" in page_type or "signup" in page_type:
            # Check for registration page specific elements
            registration_needed_elements = {
                "terms": any("terms" in comp.get("name", "").lower() or "privacy" in comp.get("name", "").lower() or "agreement" in comp.get("name", "").lower() for comp in components),
                "password_requirements": any("requirement" in comp.get("name", "").lower() or "hint" in comp.get("name", "").lower() for comp in components),
                "login_link": any("sign in" in comp.get("name", "").lower() or "login" in comp.get("name", "").lower() for comp in components)
            }
            
            if not registration_needed_elements["terms"]:
                missing_elements.append({
                    "element": "Terms & Privacy Agreement",
                    "importance": "High",
                    "reason": "Legal requirement to get user consent for terms of service and privacy policy.",
                    "recommendation": "Add a checkbox for agreeing to terms of service and privacy policy with links to the full documents."
                })
            
            if not registration_needed_elements["password_requirements"]:
                missing_elements.append({
                    "element": "Password Requirements/Hint",
                    "importance": "Medium",
                    "reason": "Users need to know password requirements upfront to create a valid password without frustration.",
                    "recommendation": "Add password requirement hints near the password field (e.g., minimum length, required characters)."
                })
            
            if not registration_needed_elements["login_link"]:
                missing_elements.append({
                    "element": "Login Link",
                    "importance": "High",
                    "reason": "Existing users may land on the registration page and need a way to go to login instead.",
                    "recommendation": "Add a 'Already have an account? Log in' link near the registration form."
                })
                
        # Add some generic recommendations for any page type
        # Check for common accessibility elements
        accessibility_elements = {
            "dark_mode": any("dark" in comp.get("name", "").lower() or "theme" in comp.get("name", "").lower() for comp in components),
            "language_selector": any("language" in comp.get("name", "").lower() or "translate" in comp.get("name", "").lower() for comp in components)
        }
        
        if not accessibility_elements["dark_mode"]:
            missing_elements.append({
                "element": "Dark Mode Toggle",
                "importance": "Low",
                "reason": "Dark mode reduces eye strain in low-light environments and is preferred by many users.",
                "recommendation": "Add a dark/light mode toggle in the header or settings section."
            })
        
        if not accessibility_elements["language_selector"] and len(components) > 10:  # Only suggest for larger components
            missing_elements.append({
                "element": "Language Selector",
                "importance": "Low",
                "reason": "For applications with international users, language selection improves accessibility.",
                "recommendation": "Add a language selector dropdown in the header or footer if your application supports multiple languages."
            })
        
        logger.info(f"Generated {len(missing_elements)} demo missing elements recommendations")
        return missing_elements