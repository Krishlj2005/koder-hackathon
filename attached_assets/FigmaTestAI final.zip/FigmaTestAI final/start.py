#!/usr/bin/env python3
"""
A simple script to start the Figma Test Platform
"""
import os
import sys
import subprocess
from load_env import load_env_file

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 10):
        print("ERROR: Python 3.10 or higher is required")
        print(f"Current Python version: {sys.version}")
        sys.exit(1)

def check_dependencies():
    """Check if required packages are installed"""
    try:
        import flask
        import flask_sqlalchemy
        import google.generativeai
        import requests
        import selenium
    except ImportError as e:
        print(f"ERROR: Missing dependency: {e}")
        print("\nPlease install all required dependencies:")
        print("pip install Flask Flask-SQLAlchemy google-generativeai requests selenium webdriver-manager")
        sys.exit(1)

def setup_environment():
    """Set up environment variables"""
    try:
        # Load environment variables from .env file
        load_env_file()
        
        # Check for required API keys (if not in demo mode)
        if not os.environ.get('DEMO_MODE') == 'true':
            if not os.environ.get('FIGMA_ACCESS_TOKEN'):
                print("WARNING: FIGMA_ACCESS_TOKEN environment variable not set")
                print("You will need to use Demo Mode for Figma API features")
            
            if not os.environ.get('GEMINI_API_KEY'):
                print("WARNING: GEMINI_API_KEY environment variable not set")
                print("You will need to use Demo Mode for AI-powered features")
        
    except Exception as e:
        print(f"WARNING: Error setting up environment: {e}")
        print("You may need to set environment variables manually")

def start_application():
    """Start the Flask application"""
    try:
        from app import app
        
        # Get port from environment variable or use default 5000
        port = int(os.environ.get("PORT", 5000))
        
        print(f"\nStarting Figma Test Platform on port {port}...")
        print(f"Server URL: http://localhost:{port}")
        print("\nPress Ctrl+C to stop the server\n")
        
        # Run the application
        app.run(host="0.0.0.0", port=port, debug=True)
        
    except Exception as e:
        print(f"ERROR: Failed to start application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    print("=== Figma Test Platform ===")
    
    # Check Python version
    check_python_version()
    
    # Check dependencies
    check_dependencies()
    
    # Set up environment
    setup_environment()
    
    # Start application
    start_application()