from datetime import datetime
from app import db

class Project(db.Model):
    """Model representing a project that contains Figma designs and web applications for testing."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    figma_file_key = db.Column(db.String(100), nullable=False)
    web_url = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    test_runs = db.relationship('TestRun', backref='project', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Project {self.name}>'

class TestRun(db.Model):
    """Model representing a test execution run for a project."""
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, generated, running, completed, failed
    report = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    test_cases = db.relationship('TestCase', backref='test_run', cascade='all, delete-orphan')
    test_results = db.relationship('TestResult', backref='test_run', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<TestRun {self.id} for Project {self.project_id}>'

class TestCase(db.Model):
    """Model representing a single test case derived from Figma design analysis."""
    id = db.Column(db.Integer, primary_key=True)
    test_run_id = db.Column(db.Integer, db.ForeignKey('test_run.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    selector = db.Column(db.String(255), nullable=True)  # CSS selector or XPath
    expected_result = db.Column(db.Text, nullable=False)
    element_type = db.Column(db.String(50), nullable=True)  # button, input, form, etc.
    screenshot_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    test_results = db.relationship('TestResult', backref='test_case', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<TestCase {self.name}>'

class TestResult(db.Model):
    """Model representing the result of executing a test case."""
    id = db.Column(db.Integer, primary_key=True)
    test_run_id = db.Column(db.Integer, db.ForeignKey('test_run.id'), nullable=False)
    test_case_id = db.Column(db.Integer, db.ForeignKey('test_case.id'), nullable=False)
    status = db.Column(db.String(20), nullable=False)  # passed, failed, error
    message = db.Column(db.Text, nullable=True)
    screenshot_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<TestResult {self.status} for TestCase {self.test_case_id}>'