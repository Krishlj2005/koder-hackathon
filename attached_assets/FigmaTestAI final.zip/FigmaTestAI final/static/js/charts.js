/**
 * Charts functionality for the Figma Test Platform
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts if their containers exist
    if (document.getElementById('resultsChart')) {
        initTestResultsChart(document.getElementById('resultsChart'));
    }
    
    if (document.getElementById('testTypesChart')) {
        initTestTypesChart(document.getElementById('testTypesChart'));
    }
    
    // Check for any test runs that need status polling
    checkForRunningTests();
});

/**
 * Initialize the test results pie chart
 * @param {HTMLElement} chartElement - The canvas element for the chart
 */
function initTestResultsChart(chartElement) {
    // Get data from data attributes or from the DOM
    const passed = parseInt(chartElement.dataset.passed) || 0;
    const failed = parseInt(chartElement.dataset.failed) || 0;
    const error = parseInt(chartElement.dataset.error) || 0;
    
    new Chart(chartElement, {
        type: 'pie',
        data: {
            labels: ['Passed', 'Failed', 'Error'],
            datasets: [{
                data: [passed, failed, error],
                backgroundColor: [
                    'rgba(40, 167, 69, 0.7)',
                    'rgba(220, 53, 69, 0.7)',
                    'rgba(255, 193, 7, 0.7)'
                ],
                borderColor: [
                    'rgba(40, 167, 69, 1)',
                    'rgba(220, 53, 69, 1)',
                    'rgba(255, 193, 7, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        color: 'white'
                    }
                }
            }
        }
    });
}

/**
 * Initialize the test types bar chart
 * @param {HTMLElement} chartElement - The canvas element for the chart
 */
function initTestTypesChart(chartElement) {
    // Get data from data attributes or data elements
    const labels = JSON.parse(chartElement.dataset.labels || '[]');
    const data = JSON.parse(chartElement.dataset.values || '[]');
    
    new Chart(chartElement, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Number of Tests',
                data: data,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        color: 'white'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                y: {
                    ticks: {
                        color: 'white'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: 'white'
                    }
                }
            }
        }
    });
}

/**
 * Update a test run status in real-time
 * @param {number} projectId - The project ID
 * @param {number} testRunId - The test run ID
 */
function pollTestRunStatus(projectId, testRunId) {
    const statusUrl = `/api/test-runs/${projectId}/${testRunId}/status`;
    
    function checkStatus() {
        fetch(statusUrl)
            .then(response => response.json())
            .then(data => {
                // If status has changed, reload the page
                if (data.status !== 'running') {
                    window.location.reload();
                } else {
                    // Otherwise, check again after a delay
                    setTimeout(checkStatus, 3000);
                }
            })
            .catch(error => {
                console.error('Error polling test run status:', error);
                // Retry after a delay
                setTimeout(checkStatus, 5000);
            });
    }
    
    // Start polling
    checkStatus();
}

/**
 * Check for running tests that need status polling
 */
function checkForRunningTests() {
    const runningStatusBadges = document.querySelectorAll('.badge[data-test-status="running"]');
    
    runningStatusBadges.forEach(badge => {
        const projectId = badge.dataset.projectId;
        const testRunId = badge.dataset.testRunId;
        
        if (projectId && testRunId) {
            pollTestRunStatus(projectId, testRunId);
        }
    });
}