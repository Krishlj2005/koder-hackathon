/**
 * Main JavaScript file for the Figma Test Platform
 */

document.addEventListener('DOMContentLoaded', function() {
    // Attach all event handlers
    attachProjectHandlers();
    attachTestHandlers();
    
    // Check for running tests
    checkForRunningTests();
});

/**
 * Attach event handlers for project-related actions
 */
function attachProjectHandlers() {
    // Form validation for new project
    const newProjectForm = document.querySelector('form[action*="new_project"]');
    if (newProjectForm) {
        newProjectForm.addEventListener('submit', function(event) {
            const nameInput = document.getElementById('projectName');
            const figmaUrlInput = document.getElementById('figmaUrl');
            const webUrlInput = document.getElementById('webUrl');
            
            let isValid = true;
            
            // Validate name
            if (!nameInput.value.trim()) {
                showValidationError(nameInput, 'Project name is required');
                isValid = false;
            } else {
                clearValidationError(nameInput);
            }
            
            // Validate Figma URL
            if (!figmaUrlInput.value.trim()) {
                showValidationError(figmaUrlInput, 'Figma URL is required');
                isValid = false;
            } else if (!figmaUrlInput.value.includes('figma.com/file/')) {
                showValidationError(figmaUrlInput, 'Please enter a valid Figma file URL');
                isValid = false;
            } else {
                clearValidationError(figmaUrlInput);
            }
            
            // Validate Web URL
            if (!webUrlInput.value.trim()) {
                showValidationError(webUrlInput, 'Web URL is required');
                isValid = false;
            } else if (!isValidUrl(webUrlInput.value)) {
                showValidationError(webUrlInput, 'Please enter a valid URL');
                isValid = false;
            } else {
                clearValidationError(webUrlInput);
            }
            
            if (!isValid) {
                event.preventDefault();
            }
        });
        
        // Auto-extract Figma file key from URL
        const figmaUrlInput = document.getElementById('figmaUrl');
        if (figmaUrlInput) {
            figmaUrlInput.addEventListener('blur', function() {
                const figmaUrl = figmaUrlInput.value.trim();
                if (figmaUrl && figmaUrl.includes('figma.com/file/')) {
                    const fileKey = extractFigmaFileKey(figmaUrl);
                    if (fileKey) {
                        console.log(`Extracted Figma file key: ${fileKey}`);
                    }
                }
            });
        }
    }
}

/**
 * Attach event handlers for test-related actions
 */
function attachTestHandlers() {
    // Add loading indicators to test action buttons
    const actionButtons = document.querySelectorAll('form[action*="generate-tests"] button, form[action*="execute"] button, form[action*="report"] button');
    
    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            showSpinner(button);
            setTimeout(() => {
                button.closest('form').submit();
            }, 100);
        });
    });
}

/**
 * Check for running tests that need to be monitored
 */
function checkForRunningTests() {
    // Look for any elements with data-test-status="running"
    const runningTests = document.querySelectorAll('[data-test-status="running"]');
    
    runningTests.forEach(element => {
        const projectId = element.dataset.projectId;
        const testRunId = element.dataset.testRunId;
        
        if (projectId && testRunId) {
            // Set up polling for test status
            pollTestRunStatus(projectId, testRunId);
        }
    });
}

/**
 * Show a validation error message
 * @param {HTMLElement} inputElement - The input element with the error
 * @param {string} message - The error message to display
 */
function showValidationError(inputElement, message) {
    // Clear any existing error
    clearValidationError(inputElement);
    
    // Add is-invalid class to the input
    inputElement.classList.add('is-invalid');
    
    // Create and insert error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'invalid-feedback';
    errorDiv.textContent = message;
    
    // Insert after the input
    inputElement.parentNode.appendChild(errorDiv);
}

/**
 * Clear a validation error message
 * @param {HTMLElement} inputElement - The input element to clear errors for
 */
function clearValidationError(inputElement) {
    inputElement.classList.remove('is-invalid');
    
    // Remove any existing error messages
    const errorMessage = inputElement.parentNode.querySelector('.invalid-feedback');
    if (errorMessage) {
        errorMessage.remove();
    }
}

/**
 * Validate a URL
 * @param {string} url - The URL to validate
 * @returns {boolean} - Whether the URL is valid
 */
function isValidUrl(url) {
    try {
        new URL(url);
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Extract Figma file key from a Figma URL
 * @param {string} url - The Figma URL
 * @returns {string|null} - The extracted file key or null if not found
 */
function extractFigmaFileKey(url) {
    const regex = /figma\.com\/file\/([a-zA-Z0-9]+)/;
    const match = url.match(regex);
    
    return match ? match[1] : null;
}

/**
 * Show a loading spinner on a button
 * @param {HTMLElement} button - The button element
 */
function showSpinner(button) {
    // Store the original button text
    button.dataset.originalText = button.innerHTML;
    
    // Replace with spinner
    button.innerHTML = `
        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
        <span class="ms-1">Processing...</span>
    `;
    
    // Disable the button
    button.disabled = true;
}

/**
 * Restore a button to its original state
 * @param {HTMLElement} button - The button element
 */
function restoreButton(button) {
    if (button.dataset.originalText) {
        button.innerHTML = button.dataset.originalText;
        button.disabled = false;
    }
}

/**
 * Poll for test run status updates
 * @param {number} projectId - The project ID
 * @param {number} testRunId - The test run ID
 */
function pollTestRunStatus(projectId, testRunId) {
    const statusUrl = `/api/test-runs/${projectId}/${testRunId}/status`;
    
    // Function to check status
    function checkStatus() {
        fetch(statusUrl)
            .then(response => response.json())
            .then(data => {
                // If test is no longer running, reload the page
                if (data.status !== 'running') {
                    window.location.reload();
                } else {
                    // Otherwise, check again in 3 seconds
                    setTimeout(checkStatus, 3000);
                }
            })
            .catch(error => {
                console.error('Error polling for test status:', error);
                // Try again in 5 seconds if there was an error
                setTimeout(checkStatus, 5000);
            });
    }
    
    // Start polling
    checkStatus();
}