import os
import base64
import json
import logging
import requests
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class GitHubActionsClient:
    """
    Client for interacting with GitHub Actions API to trigger CI/CD workflows.
    """
    
    def __init__(self, github_token: Optional[str] = None, repo_owner: Optional[str] = None, repo_name: Optional[str] = None):
        """
        Initialize the GitHub Actions client.
        
        Args:
            github_token: GitHub Personal Access Token with repo and workflow permissions.
                         If not provided, it will try to get it from the GITHUB_TOKEN env var.
            repo_owner: GitHub repository owner/org name
            repo_name: GitHub repository name
        """
        self.github_token = github_token or os.environ.get("GITHUB_TOKEN")
        self.demo_mode = False
        
        # Check if we have all the required parameters
        if not self.github_token:
            logger.warning("No GitHub token provided, will use demo mode")
            self.demo_mode = True
        
        if not repo_owner or not repo_name:
            logger.warning("Repository owner or name not provided, will use demo values")
            self.demo_mode = True
            
        # Set repo owner and name (use demo values if not provided)
        self.repo_owner = repo_owner or "demo-owner"
        self.repo_name = repo_name or "demo-repo"
        
        # Even in demo mode, set base_url and headers for consistent API
        self.base_url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}"
        self.headers = {
            "Authorization": f"token {self.github_token or 'demo-token'}",
            "Accept": "application/vnd.github.v3+json",
            "Content-Type": "application/json"
        }
    
    def list_workflows(self) -> Dict[str, Any]:
        """
        List all workflows in the repository.
        
        Returns:
            Dict containing workflow data
        
        Raises:
            Exception: If the request fails
        """
        # If in demo mode, return demo workflow data
        if self.demo_mode:
            logger.info("Using demo mode for GitHub Actions workflow list")
            return {
                "total_count": 1,
                "workflows": [
                    {
                        "id": 12345,
                        "name": "Figma Test Workflow",
                        "path": ".github/workflows/figma_test_workflow.yml",
                        "state": "active",
                        "created_at": "2025-03-30T00:00:00Z",
                        "updated_at": "2025-03-30T00:00:00Z",
                        "url": f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/actions/workflows/12345",
                        "html_url": f"https://github.com/{self.repo_owner}/{self.repo_name}/actions/workflows/12345",
                        "badge_url": f"https://github.com/{self.repo_owner}/{self.repo_name}/workflows/Figma%20Test%20Workflow/badge.svg"
                    }
                ]
            }
            
        url = f"{self.base_url}/actions/workflows"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error listing workflows: {str(e)}")
            raise Exception(f"Failed to list workflows: {str(e)}")
    
    def trigger_workflow(self, figma_file_key: str, web_url: str, workflow_id: str = "figma_test_workflow.yml") -> str:
        """
        Trigger a workflow run.
        
        Args:
            figma_file_key: Figma file key to use in the workflow
            web_url: Web URL to test in the workflow
            workflow_id: Workflow ID or filename
        
        Returns:
            ID of the triggered workflow run
        
        Raises:
            Exception: If the request fails
        """
        # If in demo mode, return a fake run ID
        if self.demo_mode:
            logger.info("Using demo mode for GitHub Actions workflow")
            return f"demo-workflow-run-{hash(figma_file_key + web_url) % 10000}"
            
        url = f"{self.base_url}/actions/workflows/{workflow_id}/dispatches"
        
        data = {
            "ref": "main",  # Branch to run the workflow on
            "inputs": {
                "figma_file_key": figma_file_key,
                "web_url": web_url
            }
        }
        
        try:
            response = requests.post(url, headers=self.headers, json=data)
            response.raise_for_status()
            
            # Get the run ID of the triggered workflow
            runs_url = f"{self.base_url}/actions/workflows/{workflow_id}/runs"
            runs_response = requests.get(runs_url, headers=self.headers)
            runs_response.raise_for_status()
            runs_data = runs_response.json()
            
            if runs_data["total_count"] > 0:
                return str(runs_data["workflow_runs"][0]["id"])
            else:
                return "Workflow triggered, but could not get run ID"
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error triggering workflow: {str(e)}")
            raise Exception(f"Failed to trigger workflow: {str(e)}")
    
    def get_workflow_run(self, run_id: str) -> Dict[str, Any]:
        """
        Get details of a workflow run.
        
        Args:
            run_id: Workflow run ID
        
        Returns:
            Dict containing workflow run data
        
        Raises:
            Exception: If the request fails
        """
        # If in demo mode, return demo workflow data
        if self.demo_mode or run_id.startswith("demo-workflow-run-"):
            logger.info("Using demo mode for GitHub Actions workflow run details")
            return {
                "id": run_id,
                "name": "Figma Test Workflow",
                "status": "completed",
                "conclusion": "success",
                "created_at": "2025-03-30T00:00:00Z",
                "updated_at": "2025-03-30T00:10:00Z",
                "url": f"https://github.com/{self.repo_owner}/{self.repo_name}/actions/runs/{run_id}",
                "html_url": f"https://github.com/{self.repo_owner}/{self.repo_name}/actions/runs/{run_id}",
                "jobs_url": f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/actions/runs/{run_id}/jobs",
                "logs_url": f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/actions/runs/{run_id}/logs",
                "repository": {
                    "name": self.repo_name,
                    "full_name": f"{self.repo_owner}/{self.repo_name}"
                }
            }
            
        url = f"{self.base_url}/actions/runs/{run_id}"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting workflow run: {str(e)}")
            raise Exception(f"Failed to get workflow run: {str(e)}")
    
    def create_workflow_file(self, content: str) -> bool:
        """
        Create or update a workflow file in the repository.
        
        Args:
            content: Content of the workflow file
        
        Returns:
            True if successful, False otherwise
        
        Raises:
            Exception: If the request fails
        """
        # If in demo mode, just return success
        if self.demo_mode:
            logger.info("Using demo mode for GitHub Actions workflow file creation")
            return True
            
        workflow_path = ".github/workflows/figma_test_workflow.yml"
        url = f"{self.base_url}/contents/{workflow_path}"
        
        try:
            # First check if the file exists
            try:
                response = requests.get(url, headers=self.headers)
                response.raise_for_status()
                current_file = response.json()
                sha = current_file["sha"]
                update = True
            except:
                update = False
                sha = None
            
            # Encode content to base64
            content_bytes = content.encode("utf-8")
            content_base64 = base64.b64encode(content_bytes).decode("utf-8")
            
            data = {
                "message": "Update Figma test workflow",
                "content": content_base64,
                "branch": "main"
            }
            
            if update and sha:
                data["sha"] = sha
            
            response = requests.put(url, headers=self.headers, json=data)
            response.raise_for_status()
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating workflow file: {str(e)}")
            raise Exception(f"Failed to create workflow file: {str(e)}")
    
    def get_default_workflow_content(self) -> str:
        """
        Get the default content for the Figma test workflow.
        
        Returns:
            YAML content for the workflow file
        """
        return """
name: Figma Test Workflow

on:
  workflow_dispatch:
    inputs:
      figma_file_key:
        description: 'Figma file key'
        required: true
      web_url:
        description: 'Web URL to test'
        required: true

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v2
      
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.10'
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install flask flask-sqlalchemy selenium openai google-generativeai requests pytest pytest-html
      
      - name: Set up Chrome
        uses: browser-actions/setup-chrome@latest
      
      - name: Install ChromeDriver
        run: |
          CHROME_VERSION=$(google-chrome --version | cut -d " " -f 3 | cut -d "." -f 1)
          wget -q "https://chromedriver.storage.googleapis.com/LATEST_RELEASE_$CHROME_VERSION" -O - | xargs -I{} wget -q "https://chromedriver.storage.googleapis.com/{}/chromedriver_linux64.zip"
          unzip chromedriver_linux64.zip
          chmod +x chromedriver
          sudo mv chromedriver /usr/local/bin/
      
      - name: Run tests
        env:
          FIGMA_ACCESS_TOKEN: ${{ secrets.FIGMA_ACCESS_TOKEN }}
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          GEMINI_API_KEY: ${{ secrets.GEMINI_API_KEY }}
          AI_PROVIDER: ${{ secrets.AI_PROVIDER || 'gemini' }}
        run: |
          python run_tests.py --figma-file-key ${{ github.event.inputs.figma_file_key }} --web-url ${{ github.event.inputs.web_url }}
      
      - name: Generate HTML report
        run: |
          pytest test_results.py --html=report.html
        continue-on-error: true
      
      - name: Upload test results
        uses: actions/upload-artifact@v2
        with:
          name: test-results
          path: |
            screenshots/
            report.html
        if: always()
      
      - name: Send notification
        if: always()
        uses: dawidd6/action-send-mail@v3
        with:
          server_address: ${{ secrets.MAIL_SERVER }}
          server_port: ${{ secrets.MAIL_PORT }}
          username: ${{ secrets.MAIL_USERNAME }}
          password: ${{ secrets.MAIL_PASSWORD }}
          subject: Figma Test Results for ${{ github.event.inputs.figma_file_key }}
          body: |
            Test results for Figma file: ${{ github.event.inputs.figma_file_key }}
            Web URL: ${{ github.event.inputs.web_url }}
            
            Status: ${{ job.status }}
            
            Download the test report from GitHub Actions to view details.
          to: ${{ secrets.NOTIFICATION_EMAIL }}
          from: GitHub Actions
        continue-on-error: true
"""