import argparse
import os
import logging
import json
import sys
from figma_client import FigmaClient
from test_generator import TestGenerator
from selenium_executor import SeleniumExecutor

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Run automated tests based on Figma designs')
    parser.add_argument('--figma-file-key', required=True, help='Figma file key')
    parser.add_argument('--web-url', required=True, help='URL of the web application to test')
    parser.add_argument('--output-dir', default='test_results', help='Directory to save test results')
    parser.add_argument('--headless', action='store_true', default=True, help='Run tests in headless mode')
    return parser.parse_args()

def setup_environment(args):
    """Set up environment for testing."""
    # Create output directory if it doesn't exist
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Create screenshot directory if it doesn't exist
    screenshot_dir = os.path.join(args.output_dir, 'screenshots')
    os.makedirs(screenshot_dir, exist_ok=True)
    
    # Check if required environment variables are set
    figma_token = os.environ.get('FIGMA_ACCESS_TOKEN')
    openai_key = os.environ.get('OPENAI_API_KEY')
    
    if not figma_token:
        logger.error('FIGMA_ACCESS_TOKEN environment variable is not set')
        sys.exit(1)
    
    if not openai_key:
        logger.error('OPENAI_API_KEY environment variable is not set')
        sys.exit(1)
    
    # Return environment configuration
    return {
        'figma_token': figma_token,
        'openai_key': openai_key,
        'screenshot_dir': screenshot_dir,
        'output_dir': args.output_dir
    }

def run_tests(args, env):
    """Run the automated test process."""
    try:
        # Step 1: Fetch Figma design
        logger.info(f"Fetching Figma design for file key: {args.figma_file_key}")
        figma_client = FigmaClient(env['figma_token'])
        figma_data = figma_client.get_file(args.figma_file_key)
        
        # Step 2: Generate test cases
        logger.info("Generating test cases based on Figma design")
        test_generator = TestGenerator(env['openai_key'])
        test_cases = test_generator.generate_test_cases(figma_data, args.web_url)
        
        # Save test cases to file
        test_cases_file = os.path.join(env['output_dir'], 'test_cases.json')
        with open(test_cases_file, 'w') as f:
            json.dump(test_cases, f, indent=2)
        
        logger.info(f"Generated {len(test_cases)} test cases, saved to {test_cases_file}")
        
        # Step 3: Execute tests
        logger.info(f"Executing tests against web application at {args.web_url}")
        selenium_executor = SeleniumExecutor(headless=args.headless, screenshot_dir=env['screenshot_dir'])
        test_results = selenium_executor.execute_tests(args.web_url, test_cases)
        
        # Save test results to file
        test_results_file = os.path.join(env['output_dir'], 'test_results.json')
        with open(test_results_file, 'w') as f:
            json.dump(test_results, f, indent=2)
        
        logger.info(f"Test execution completed, results saved to {test_results_file}")
        
        # Calculate pass rate
        passed = sum(1 for result in test_results if result.get('status') == 'passed')
        total = len(test_results)
        pass_rate = (passed / total) * 100 if total > 0 else 0
        
        logger.info(f"Test summary: {passed}/{total} passed ({pass_rate:.1f}%)")
        
        return test_cases, test_results
    
    except Exception as e:
        logger.error(f"Error running tests: {str(e)}")
        sys.exit(1)

def main():
    """Main entry point for the script."""
    # Parse command line arguments
    args = parse_arguments()
    
    # Set up environment
    env = setup_environment(args)
    
    # Run tests
    test_cases, test_results = run_tests(args, env)
    
    # Exit with appropriate status code
    failed_count = sum(1 for result in test_results if result.get('status') != 'passed')
    sys.exit(1 if failed_count > 0 else 0)

if __name__ == '__main__':
    main()