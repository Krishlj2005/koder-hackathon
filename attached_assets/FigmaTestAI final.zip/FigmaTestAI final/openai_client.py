import os
import json
import logging
from typing import Dict, List, Any, Optional

from openai import OpenAI

logger = logging.getLogger(__name__)

class OpenAIClient:
    """
    Client for interacting with OpenAI API for content generation and image analysis.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the OpenAI client.
        
        Args:
            api_key: OpenAI API key for generating content.
                   If not provided, it will try to get it from the OPENAI_API_KEY env var.
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.demo_mode = False
        
        # Try to initialize OpenAI client
        if self.api_key:
            try:
                self.client = OpenAI(api_key=self.api_key)
                # Use gpt-4o which was released May 13, 2024 - do not change this unless explicitly requested by the user
                self.model = "gpt-4o"
                logger.info(f"OpenAI client initialized successfully with model {self.model}")
            except Exception as e:
                logger.warning(f"Failed to initialize OpenAI client: {str(e)}. Will use demo mode.")
                self.demo_mode = True
        else:
            logger.warning("No OpenAI API key provided. Will use demo mode.")
            self.demo_mode = True
    
    def generate_content(self, prompt: str, response_format: str = None) -> str:
        """
        Generate content from a prompt using OpenAI.
        
        Args:
            prompt: The prompt to send to OpenAI.
            response_format: Optional string indicating desired response format (e.g., 'json').
                            If 'json', the method will use the response_format parameter.
        
        Returns:
            Generated content as a string.
        
        Raises:
            Exception: If content generation fails.
        """
        if self.demo_mode:
            logger.info("Using demo mode for OpenAI content generation")
            
            # For JSON responses, return a valid JSON string
            if response_format == 'json':
                return '{"status": "demo", "message": "This is a demo response in JSON format from OpenAI"}'
            
            # Return a generic demo response for text
            return "This is a demo response from the OpenAI client."
        
        try:
            # Set up response format if needed
            openai_response_format = None
            if response_format == 'json':
                openai_response_format = {"type": "json_object"}
            
            # Generate the response from OpenAI
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt}
                ],
                response_format=openai_response_format
            )
            
            # Extract the text content
            content = response.choices[0].message.content
            
            return content
            
        except Exception as e:
            logger.error(f"Error generating content with OpenAI: {str(e)}")
            raise Exception(f"Failed to generate content with OpenAI: {str(e)}")
    
    def analyze_image(self, base64_image: str, prompt: str = None) -> str:
        """
        Analyze an image using OpenAI's vision capabilities.
        
        Args:
            base64_image: The base64-encoded image data.
            prompt: Optional specific instructions for the image analysis.
                   If not provided, a default prompt will be used.
        
        Returns:
            Analysis of the image as a string.
        
        Raises:
            Exception: If image analysis fails.
        """
        if self.demo_mode:
            logger.info("Using demo mode for OpenAI image analysis")
            return "This is a demo image analysis from the OpenAI client."
        
        try:
            # Use default prompt if none provided
            if not prompt:
                prompt = "Analyze this image in detail and describe its key elements, context, and any notable aspects."
            
            # Create the API request with the image
            response = self.client.chat.completions.create(
                model="gpt-4o",  # Using the multimodal model
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url", 
                                "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
                            }
                        ]
                    }
                ],
                max_tokens=500
            )
            
            # Extract and return the analysis
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error analyzing image with OpenAI: {str(e)}")
            raise Exception(f"Failed to analyze image with OpenAI: {str(e)}")
    
    def generate_image(self, prompt: str, size: str = "1024x1024") -> Dict[str, str]:
        """
        Generate an image using DALL-E.
        
        Args:
            prompt: The description of the image to generate.
            size: Size of the image (1024x1024, 512x512, etc.)
        
        Returns:
            Dict containing the URL of the generated image.
        
        Raises:
            Exception: If image generation fails.
        """
        if self.demo_mode:
            logger.info("Using demo mode for OpenAI image generation")
            return {"url": "https://via.placeholder.com/1024x1024?text=Demo+Image"}
        
        try:
            # Generate the image
            response = self.client.images.generate(
                model="dall-e-3",
                prompt=prompt,
                n=1,
                size=size
            )
            
            # Return the image URL
            return {"url": response.data[0].url}
            
        except Exception as e:
            logger.error(f"Error generating image with DALL-E: {str(e)}")
            raise Exception(f"Failed to generate image with DALL-E: {str(e)}")
    
    def transcribe_audio(self, audio_file_path: str) -> str:
        """
        Transcribe audio using Whisper.
        
        Args:
            audio_file_path: Path to the audio file.
        
        Returns:
            Transcribed text.
        
        Raises:
            Exception: If transcription fails.
        """
        if self.demo_mode:
            logger.info("Using demo mode for OpenAI audio transcription")
            return "This is a demo transcription from the OpenAI client."
        
        try:
            # Open and transcribe the audio file
            with open(audio_file_path, "rb") as audio_file:
                response = self.client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file
                )
            
            # Return the transcribed text
            return response.text
            
        except Exception as e:
            logger.error(f"Error transcribing audio with Whisper: {str(e)}")
            raise Exception(f"Failed to transcribe audio with Whisper: {str(e)}")