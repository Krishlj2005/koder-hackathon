import os
import logging
from typing import Dict, List, Any, Optional

from gemini_client import GeminiClient
from openai_client import OpenAIClient

logger = logging.getLogger(__name__)

# Check if running in Replit environment
IS_REPLIT = "REPL_ID" in os.environ or "REPLIT_OWNER" in os.environ

# Default provider for Replit environment
DEFAULT_PROVIDER = "gemini" if IS_REPLIT else None

class AIClient:
    """
    A unified client for interacting with various AI providers.
    This class abstracts away the specifics of each AI provider and presents a consistent interface.
    """
    
    def __init__(self, provider: str = None, api_key: Optional[str] = None):
        """
        Initialize the AI client with the specified provider.
        
        Args:
            provider: The AI provider to use ('openai', 'gemini'). 
                    If not specified, it will try to determine based on available API keys.
            api_key: API key for the specified provider. 
                    If not provided, it will try to get it from environment variables.
        """
        # Use the environment-based default provider if none is specified
        self.provider = provider or DEFAULT_PROVIDER
        self.api_key = api_key
        self.client = None
        
        # If still no provider specified, determine based on available API keys
        if not self.provider:
            env_provider = os.environ.get("AI_PROVIDER", "").lower()
            if env_provider in ("openai", "gemini"):
                self.provider = env_provider
            elif os.environ.get("OPENAI_API_KEY"):
                self.provider = "openai"
            elif os.environ.get("GEMINI_API_KEY"):
                self.provider = "gemini"
            else:
                # Default to Gemini if no keys are available (best for Replit)
                self.provider = "gemini"
                logger.warning("No API keys found for any provider. Will use demo mode.")
        
        # Initialize the appropriate client
        if self.provider.lower() == "openai":
            self.client = OpenAIClient(api_key=api_key)
            logger.info("Using OpenAI as the AI provider")
        elif self.provider.lower() == "gemini":
            self.client = GeminiClient(api_key=api_key)
            logger.info("Using Gemini as the AI provider")
        else:
            raise ValueError(f"Unsupported AI provider: {provider}")
            
        # Check if client is in demo mode
        self.demo_mode = getattr(self.client, "demo_mode", False)
        if self.demo_mode:
            logger.warning(f"AI client for {self.provider} is running in demo mode")
    
    def generate_content(self, prompt: str, response_format: str = None) -> str:
        """
        Generate content from a prompt using the selected AI provider.
        
        Args:
            prompt: The prompt to send to the AI.
            response_format: Optional string indicating desired response format (e.g., 'json').
        
        Returns:
            Generated content as a string.
        
        Raises:
            Exception: If content generation fails.
        """
        return self.client.generate_content(prompt, response_format)
    
    def analyze_image(self, base64_image: str, prompt: str = None) -> str:
        """
        Analyze an image using the selected AI provider's vision capabilities.
        
        Args:
            base64_image: The base64-encoded image data.
            prompt: Optional specific instructions for the image analysis.
        
        Returns:
            Analysis of the image as a string.
        
        Raises:
            Exception: If image analysis fails.
        """
        if hasattr(self.client, "analyze_image"):
            return self.client.analyze_image(base64_image, prompt)
        else:
            logger.warning(f"Image analysis not supported by {self.provider}")
            return "Image analysis not supported by the selected AI provider."
    
    def generate_image(self, prompt: str, size: str = "1024x1024") -> Dict[str, str]:
        """
        Generate an image using the selected AI provider's image generation capabilities.
        
        Args:
            prompt: The description of the image to generate.
            size: Size of the image.
        
        Returns:
            Dict containing the URL of the generated image.
        
        Raises:
            Exception: If image generation fails.
        """
        if hasattr(self.client, "generate_image"):
            return self.client.generate_image(prompt, size)
        else:
            logger.warning(f"Image generation not supported by {self.provider}")
            return {"url": "https://via.placeholder.com/1024x1024?text=Not+Supported"}
    
    def transcribe_audio(self, audio_file_path: str) -> str:
        """
        Transcribe audio using the selected AI provider's audio transcription capabilities.
        
        Args:
            audio_file_path: Path to the audio file.
        
        Returns:
            Transcribed text.
        
        Raises:
            Exception: If transcription fails.
        """
        if hasattr(self.client, "transcribe_audio"):
            return self.client.transcribe_audio(audio_file_path)
        else:
            logger.warning(f"Audio transcription not supported by {self.provider}")
            return "Audio transcription not supported by the selected AI provider."