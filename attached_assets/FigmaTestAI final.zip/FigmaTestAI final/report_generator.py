import os
import logging
import json
from typing import Dict, List, Any, Optional

from ai_client import AIClient

logger = logging.getLogger(__name__)

class ReportGenerator:
    """
    Generates test reports with recommendations for improvements.
    Uses a unified AI client to support multiple AI providers.
    """
    
    def __init__(self, api_key: Optional[str] = None, provider: Optional[str] = None):
        """
        Initialize the report generator.
        
        Args:
            api_key: API key for the AI provider.
                    If not provided, it will try to get it from environment variables.
            provider: The AI provider to use ('openai', 'gemini').
                     If not specified, it will try to determine based on available API keys.
        """
        self.demo_mode = False
        
        # Initialize the AI client
        try:
            self.ai_client = AIClient(provider=provider, api_key=api_key)
            self.demo_mode = self.ai_client.demo_mode
            logger.info(f"Report generator initialized with {self.ai_client.provider} provider")
        except Exception as e:
            logger.warning(f"Failed to initialize AI client: {str(e)}. Will use demo mode.")
            self.demo_mode = True
    
    def generate_report(self, project: Any, test_run: Any, test_cases: List[Any], test_results: List[Any]) -> str:
        """
        Generate a comprehensive test report with recommendations.
        
        Args:
            project: Project object
            test_run: TestRun object
            test_cases: List of TestCase objects
            test_results: List of TestResult objects
        
        Returns:
            HTML report content
        """
        # Calculate stats
        total_tests = len(test_cases)
        passed_tests = sum(1 for result in test_results if result.status == 'passed')
        failed_tests = sum(1 for result in test_results if result.status == 'failed')
        error_tests = sum(1 for result in test_results if result.status == 'error')
        
        if total_tests > 0:
            pass_rate = (passed_tests / total_tests) * 100
        else:
            pass_rate = 0
        
        # Create test data for AI recommendations
        test_data = []
        for test_case, test_result in zip(test_cases, test_results):
            test_data.append({
                "name": test_case.name,
                "description": test_case.description,
                "selector": test_case.selector,
                "expected_result": test_case.expected_result,
                "element_type": test_case.element_type,
                "status": test_result.status,
                "message": test_result.message
            })
        
        # Generate AI recommendations
        recommendations_html = self._generate_recommendations(project.web_url, test_data)
        
        # Build the HTML report
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Test Report - {project.name}</title>
            <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <style>
                .report-header {{
                    padding: 2rem 0;
                    margin-bottom: 2rem;
                    background-color: var(--bs-dark);
                    border-radius: 0.5rem;
                }}
                .summary-card {{
                    border-radius: 0.5rem;
                    margin-bottom: 1rem;
                }}
                .screenshot {{
                    max-width: 100%;
                    height: auto;
                    border: 1px solid var(--bs-gray-600);
                    border-radius: 0.5rem;
                    margin-top: 1rem;
                }}
                .recommendations {{
                    margin-top: 2rem;
                    padding: 2rem;
                    background-color: var(--bs-dark);
                    border-radius: 0.5rem;
                }}
                .test-table {{
                    margin-top: 2rem;
                }}
                .test-status-passed {{
                    background-color: rgba(40, 167, 69, 0.2);
                }}
                .test-status-failed {{
                    background-color: rgba(220, 53, 69, 0.2);
                }}
                .test-status-error {{
                    background-color: rgba(255, 193, 7, 0.2);
                }}
                pre {{
                    background-color: var(--bs-gray-900);
                    padding: 0.5rem;
                    border-radius: 0.25rem;
                    color: var(--bs-light);
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="report-header text-center">
                    <h1>Test Report</h1>
                    <p class="lead">
                        Project: {project.name}<br>
                        Figma File: {project.figma_file_key}<br>
                        Web URL: {project.web_url}
                    </p>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card summary-card">
                            <div class="card-body">
                                <h3 class="card-title">Summary</h3>
                                <p class="card-text">
                                    Total Tests: {total_tests}<br>
                                    Passed: {passed_tests}<br>
                                    Failed: {failed_tests}<br>
                                    Errors: {error_tests}<br>
                                </p>
                                <div class="progress" style="height: 30px;">
                                    <div class="progress-bar {self._get_progress_class(pass_rate)}" 
                                         role="progressbar" 
                                         style="width: {pass_rate}%;" 
                                         aria-valuenow="{pass_rate}" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                        {pass_rate:.1f}%
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card summary-card">
                            <div class="card-body">
                                <h3 class="card-title">Test Results</h3>
                                <canvas id="resultsChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="recommendations">
                    <h2>Recommendations</h2>
                    {recommendations_html}
                </div>
                
                <div class="test-table">
                    <h2>Test Details</h2>
                    <div class="table-responsive">
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>Test Case</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                 
                                </tr>
                            </thead>
                            <tbody>
                                {self._generate_test_results_table_rows(test_cases, test_results)}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <script>
                document.addEventListener('DOMContentLoaded', function() {{
                    // Results pie chart
                    const resultsCtx = document.getElementById('resultsChart').getContext('2d');
                    const resultsChart = new Chart(resultsCtx, {{
                        type: 'pie',
                        data: {{
                            labels: ['Passed', 'Failed', 'Error'],
                            datasets: [{{
                                data: [{passed_tests}, {failed_tests}, {error_tests}],
                                backgroundColor: [
                                    'rgba(40, 167, 69, 0.8)',
                                    'rgba(220, 53, 69, 0.8)',
                                    'rgba(255, 193, 7, 0.8)'
                                ],
                                borderColor: [
                                    'rgba(40, 167, 69, 1)',
                                    'rgba(220, 53, 69, 1)',
                                    'rgba(255, 193, 7, 1)'
                                ],
                                borderWidth: 1
                            }}]
                        }},
                        options: {{
                            responsive: true,
                            plugins: {{
                                legend: {{
                                    position: 'bottom',
                                    labels: {{
                                        color: 'white'
                                    }}
                                }}
                            }}
                        }}
                    }});
                }});
            </script>
        </body>
        </html>
        """
        
        return html
    
    def _generate_recommendations(self, web_url: str, test_data: List[Dict[str, Any]]) -> str:
        """
        Generate recommendations based on test results using AI.
        
        Args:
            web_url: URL of the tested website
            test_data: List of test data
        
        Returns:
            HTML content with recommendations
        """
        try:
            # If demo mode is enabled, return pre-defined recommendations
            if self.demo_mode:
                logger.info("Using demo mode to generate recommendations")
                return self._get_demo_recommendations(web_url, test_data)
                
            # Create a prompt for the AI
            prompt = f"""
            You are a UI/UX and quality assurance expert. Analyze the following test results 
            from a web application and provide actionable recommendations for improvements.
            
            Web URL: {web_url}
            
            Test Results:
            {json.dumps(test_data, indent=2)}
            
            Based on the test results:
            1. Identify patterns in failures or errors
            2. Suggest specific UI/UX improvements
            3. Recommend potential fixes for failed tests
            4. Suggest any additional tests that might be valuable
            
            Format your response as a JSON object with the following structure:
            {{
                "summary": "Brief summary of overall findings",
                "critical_issues": [
                    {{
                        "title": "Issue title",
                        "description": "Detailed description",
                        "recommendation": "Specific recommendation"
                    }}
                ],
                "ui_improvements": [
                    {{
                        "title": "Improvement title",
                        "description": "Detailed description",
                        "recommendation": "Specific recommendation"
                    }}
                ],
                "additional_tests": [
                    {{
                        "title": "Test title",
                        "description": "What the test would verify",
                        "justification": "Why this test is important"
                    }}
                ]
            }}
            """
            
            # Generate content using the AI client
            system_prompt = "You are a UI/UX and QA expert that provides recommendations based on test results."
            full_prompt = system_prompt + "\n\n" + prompt
            
            # Call the AI client to generate content
            recommendations_content = self.ai_client.generate_content(
                prompt=full_prompt,
                response_format='json'
            )
            
            # Parse the content as JSON
            recommendations_data = json.loads(recommendations_content)
            
            # Convert the JSON to HTML
            html = f"""
            <div class="alert alert-info">
                <h4>Summary</h4>
                <p>{recommendations_data.get('summary', 'No summary available.')}</p>
            </div>
            
            <h3>Critical Issues</h3>
            <div class="row">
            """
            
            # Add critical issues cards
            for issue in recommendations_data.get('critical_issues', []):
                html += f"""
                <div class="col-md-6 mb-4">
                    <div class="card bg-danger bg-opacity-25">
                        <div class="card-body">
                            <h5 class="card-title">{issue.get('title', 'Issue')}</h5>
                            <p class="card-text">{issue.get('description', '')}</p>
                            <div class="alert alert-light">
                                <strong>Recommendation:</strong> {issue.get('recommendation', '')}
                            </div>
                        </div>
                    </div>
                </div>
                """
            
            html += """
            </div>
            
            <h3>UI Improvements</h3>
            <div class="row">
            """
            
            # Add UI improvements cards
            for improvement in recommendations_data.get('ui_improvements', []):
                html += f"""
                <div class="col-md-6 mb-4">
                    <div class="card bg-info bg-opacity-25">
                        <div class="card-body">
                            <h5 class="card-title">{improvement.get('title', 'Improvement')}</h5>
                            <p class="card-text">{improvement.get('description', '')}</p>
                            <div class="alert alert-light">
                                <strong>Recommendation:</strong> {improvement.get('recommendation', '')}
                            </div>
                        </div>
                    </div>
                </div>
                """
            
            html += """
            </div>
            
            <h3>Suggested Additional Tests</h3>
            <div class="row">
            """
            
            # Add additional tests cards
            for test in recommendations_data.get('additional_tests', []):
                html += f"""
                <div class="col-md-6 mb-4">
                    <div class="card bg-secondary bg-opacity-25">
                        <div class="card-body">
                            <h5 class="card-title">{test.get('title', 'Test')}</h5>
                            <p class="card-text">{test.get('description', '')}</p>
                            <div class="alert alert-light">
                                <strong>Justification:</strong> {test.get('justification', '')}
                            </div>
                        </div>
                    </div>
                </div>
                """
            
            html += """
            </div>
            """
            
            return html
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {str(e)}")
            return f"""
            <div class="alert alert-warning">
                <h4>Error Generating Recommendations</h4>
                <p>We couldn't generate automated recommendations. Please review the test results manually.</p>
                <p>Error: {str(e)}</p>
            </div>
            """
    
    def _generate_test_results_table_rows(self, test_cases: List[Any], test_results: List[Any]) -> str:
        """Generate HTML table rows for test results."""
        rows = ""
        
        for test_case, test_result in zip(test_cases, test_results):
            status_class = ""
            if test_result.status == 'passed':
                status_class = "test-status-passed"
            elif test_result.status == 'failed':
                status_class = "test-status-failed"
            else:
                status_class = "test-status-error"
            
            screenshot_html = ""
            if test_result.screenshot_path:
                screenshot_html = f'<a href="{test_result.screenshot_path}" target="_blank"><img src="{test_result.screenshot_path}" class="screenshot" style="max-width: 200px;"></a>'
            
            rows += f"""
            <tr class="{status_class}">
                <td>{test_case.name}</td>
                <td>{test_case.description}</td>
                <td><span class="badge bg-{self._get_status_badge_class(test_result.status)}">{test_result.status.upper()}</span></td>

            </tr>
            """
        
        return rows
    
    def _get_progress_class(self, pass_rate: float) -> str:
        """Get the appropriate Bootstrap progress bar class based on pass rate."""
        if pass_rate >= 90:
            return "bg-success"
        elif pass_rate >= 70:
            return "bg-info"
        elif pass_rate >= 50:
            return "bg-warning"
        else:
            return "bg-danger"
    
    def _get_status_badge_class(self, status: str) -> str:
        """Get the appropriate Bootstrap badge class based on test status."""
        if status == 'passed':
            return "success"
        elif status == 'failed':
            return "danger"
        else:
            return "warning"
            
    def _get_demo_recommendations(self, web_url: str, test_data: List[Dict[str, Any]]) -> str:
        """
        Generate demo recommendations based on test results.
        Used when OpenAI API is not available.
        
        Args:
            web_url: URL of the tested website
            test_data: List of test data
        
        Returns:
            HTML content with demo recommendations
        """
        logger.info("Generating demo recommendations")
        
        # Count the number of passed/failed/error tests
        passed_count = sum(1 for test in test_data if test.get("status") == "passed")
        failed_count = sum(1 for test in test_data if test.get("status") == "failed")
        error_count = sum(1 for test in test_data if test.get("status") == "error")
        total_count = len(test_data)
        
        # Generate summary based on pass rate
        pass_rate = (passed_count / total_count) * 100 if total_count > 0 else 0
        
        if pass_rate >= 90:
            summary = "The application performs exceptionally well in the automated tests, with most test cases passing successfully. There are only minor issues that need attention."
        elif pass_rate >= 70:
            summary = "The application performs reasonably well, but there are several areas that need improvement to enhance the user experience and functionality."
        elif pass_rate >= 50:
            summary = "The application has significant issues that need to be addressed. Many test cases are failing, indicating potential problems with core functionality."
        else:
            summary = "The application has critical issues that require immediate attention. Most test cases are failing, suggesting major problems with functionality and user experience."
        
        # Demo recommendations data
        recommendations_data = {
            "summary": summary,
            "critical_issues": [
                {
                    "title": "Inconsistent Responsive Behavior",
                    "description": "The application does not render properly across different screen sizes and devices. Elements overlap or become inaccessible on mobile and tablet views.",
                    "recommendation": "Implement a responsive design approach using Bootstrap's grid system and media queries. Test on multiple device sizes and ensure all functionality works consistently."
                }
            ],
            "ui_improvements": [
                {
                    "title": "Enhance Form Validation Feedback",
                    "description": "Users are not receiving clear feedback when form validation fails, leading to confusion and frustration.",
                    "recommendation": "Add inline validation messages next to form fields that clearly explain the error and how to fix it. Use color-coding and icons to make errors more visible."
                },
                {
                    "title": "Improve Loading States",
                    "description": "The application lacks visual feedback during loading operations, making users unsure if their actions have been registered.",
                    "recommendation": "Implement loading spinners or progress bars for all asynchronous operations. Use skeleton screens for content that takes time to load, rather than empty spaces."
                }
            ],
            "additional_tests": [
                {
                    "title": "Cross-Browser Compatibility Testing",
                    "description": "Verify that the application works consistently across Chrome, Firefox, Safari, and Edge browsers.",
                    "justification": "Different browsers may interpret CSS and JavaScript differently, leading to inconsistent user experiences if not properly tested."
                },
                {
                    "title": "Accessibility Compliance Testing",
                    "description": "Check for WCAG 2.1 compliance, including keyboard navigation, screen reader compatibility, and sufficient color contrast.",
                    "justification": "Ensuring accessibility not only helps users with disabilities but also improves the overall usability of the application and may be legally required in many jurisdictions."
                }
            ]
        }
        
        # Add recommendations based on failed tests
        if failed_count > 0:
            # Check for common UI element types in failed tests
            failed_buttons = any(test.get("element_type") == "button" and test.get("status") == "failed" for test in test_data)
            failed_forms = any(test.get("element_type") == "form" and test.get("status") == "failed" for test in test_data)
            failed_navigation = any(("nav" in test.get("name", "").lower() or "menu" in test.get("name", "").lower()) and test.get("status") == "failed" for test in test_data)
            
            if failed_buttons:
                recommendations_data["critical_issues"].append({
                    "title": "Button Functionality Issues",
                    "description": "Several button elements are not functioning as expected, which prevents users from completing key actions.",
                    "recommendation": "Review all button click handlers, ensure proper event propagation, and verify that buttons have appropriate ARIA roles and visual feedback on interaction."
                })
            
            if failed_forms:
                recommendations_data["critical_issues"].append({
                    "title": "Form Submission Problems",
                    "description": "Form submissions are failing or not processing user input correctly, leading to data loss or incomplete operations.",
                    "recommendation": "Validate form handling logic, check for proper form submission events, and ensure that input validation is working correctly both client and server-side."
                })
            
            if failed_navigation:
                recommendations_data["ui_improvements"].append({
                    "title": "Navigation Clarity Issues",
                    "description": "The navigation structure is confusing or not functioning correctly, making it difficult for users to move through the application.",
                    "recommendation": "Simplify the navigation hierarchy, ensure consistent placement across pages, and provide clear visual indicators for the current location in the application."
                })
        
        # Convert the demo recommendations data to HTML using the same format as the real recommendations
        html = f"""
        <div class="alert alert-info">
            <h4>Summary</h4>
            <p>{recommendations_data.get('summary', 'No summary available.')}</p>
        </div>
        
        <h3>Critical Issues</h3>
        <div class="row">
        """
        
        # Add critical issues cards
        for issue in recommendations_data.get('critical_issues', []):
            html += f"""
            <div class="col-md-6 mb-4">
                <div class="card bg-danger bg-opacity-25">
                    <div class="card-body">
                        <h5 class="card-title">{issue.get('title', 'Issue')}</h5>
                        <p class="card-text">{issue.get('description', '')}</p>
                        <div class="alert alert-light">
                            <strong>Recommendation:</strong> {issue.get('recommendation', '')}
                        </div>
                    </div>
                </div>
            </div>
            """
        
        html += """
        </div>
        
        <h3>UI Improvements</h3>
        <div class="row">
        """
        
        # Add UI improvements cards
        for improvement in recommendations_data.get('ui_improvements', []):
            html += f"""
            <div class="col-md-6 mb-4">
                <div class="card bg-info bg-opacity-25">
                    <div class="card-body">
                        <h5 class="card-title">{improvement.get('title', 'Improvement')}</h5>
                        <p class="card-text">{improvement.get('description', '')}</p>
                        <div class="alert alert-light">
                            <strong>Recommendation:</strong> {improvement.get('recommendation', '')}
                        </div>
                    </div>
                </div>
            </div>
            """
        
        html += """
        </div>
        
        <h3>Suggested Additional Tests</h3>
        <div class="row">
        """
        
        # Add additional tests cards
        for test in recommendations_data.get('additional_tests', []):
            html += f"""
            <div class="col-md-6 mb-4">
                <div class="card bg-secondary bg-opacity-25">
                    <div class="card-body">
                        <h5 class="card-title">{test.get('title', 'Test')}</h5>
                        <p class="card-text">{test.get('description', '')}</p>
                        <div class="alert alert-light">
                            <strong>Justification:</strong> {test.get('justification', '')}
                        </div>
                    </div>
                </div>
            </div>
            """
        
        html += """
        </div>
        
        <div class="alert alert-secondary mt-4">
            <small><em>Note: These recommendations are generated in demo mode as sample data.</em></small>
        </div>
        """
        
        return html