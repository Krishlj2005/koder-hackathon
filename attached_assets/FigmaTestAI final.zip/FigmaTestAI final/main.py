import os
import logging
from load_env import load_env_file
from app import app

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("app")

if __name__ == "__main__":
    # Load environment variables from .env file
    load_env_file()
    
    # Set default environment variables for actual Figma website integration
    if "SIMULATION_MODE" not in os.environ:
        # Default to simulation mode in Replit environment
        if "REPL_ID" in os.environ or "REPLIT_OWNER" in os.environ:
            os.environ["SIMULATION_MODE"] = "true"
            logger.info("Running in Replit environment, enabling simulation mode for Selenium")
        else:
            os.environ["SIMULATION_MODE"] = "false"
    
    # Set AI provider if not explicitly set
    if "AI_PROVIDER" not in os.environ:
        # Select based on available API keys
        if os.environ.get("GEMINI_API_KEY"):
            os.environ["AI_PROVIDER"] = "gemini"
            logger.info("Using Gemini as default AI provider")
        elif os.environ.get("OPENAI_API_KEY"):
            os.environ["AI_PROVIDER"] = "openai" 
            logger.info("Using OpenAI as default AI provider")
        else:
            os.environ["AI_PROVIDER"] = "gemini"  # Default to Gemini
            logger.info("No API keys detected, defaulting to Gemini as AI provider")
    
    # Get port from environment variable or use default 5000
    port = int(os.environ.get("PORT", 5000))
    
    # Log startup configuration
    logger.info(f"Starting Figma QA Testing application with port {port}")
    logger.info(f"AI Provider: {os.environ.get('AI_PROVIDER')}")
    logger.info(f"Simulation Mode: {os.environ.get('SIMULATION_MODE')}")
    
    # Run the application
    app.run(host="0.0.0.0", port=port, debug=True)