# Detailed Setup Guide

This guide provides comprehensive instructions for setting up and using the Figma Test Platform in different environments.

## Local Development Setup

### Environment Setup

1. **Python Environment**:
   
   Make sure you have Python 3.10 or higher installed:
   ```bash
   python --version
   ```

   Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install Dependencies**:
   
   ```bash
   pip install -r requirements.txt
   ```

3. **Environment Variables**:
   
   Create a `.env` file by copying the template:
   ```bash
   cp .env.example .env
   ```

   Edit the `.env` file with your preferred text editor and add your API keys and configuration settings.

### Database Configuration

By default, the platform uses SQLite for simplicity. To use PostgreSQL instead:

1. Install PostgreSQL and create a database:
   ```bash
   createdb figma_test
   ```

2. Update your `.env` file:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/figma_test
   ```

### AI Provider Configuration

You can choose between Google's Gemini AI and OpenAI as your AI provider:

1. **For Gemini AI** (default):
   - Get an API key from [Google AI Studio](https://makersuite.google.com/)
   - Add to your `.env` file:
     ```
     GEMINI_API_KEY=your-gemini-api-key
     AI_PROVIDER=gemini
     ```

2. **For OpenAI**:
   - Get an API key from [OpenAI Platform](https://platform.openai.com/)
   - Add to your `.env` file:
     ```
     OPENAI_API_KEY=your-openai-api-key
     AI_PROVIDER=openai
     ```

### Figma Integration

To connect to Figma's API:

1. Get a personal access token from [Figma's developer settings](https://www.figma.com/developers/api#access-tokens)
2. Add to your `.env` file:
   ```
   FIGMA_ACCESS_TOKEN=your-figma-personal-access-token
   ```

### GitHub Actions Integration

To trigger CI/CD workflows in GitHub:

1. Generate a personal access token with `repo` and `workflow` scopes from [GitHub's developer settings](https://github.com/settings/tokens)
2. Add to your `.env` file:
   ```
   GITHUB_TOKEN=your-github-personal-access-token
   GITHUB_REPO_OWNER=your-github-username-or-org
   GITHUB_REPO_NAME=your-repository-name
   ```

## Running the Application

### Starting the Server

1. **Using the start script** (recommended):
   
   ```bash
   python start.py
   ```

2. **Using Flask directly**:
   
   ```bash
   flask run --host=0.0.0.0 --port=5000
   ```

3. **Using Gunicorn** (production):
   
   ```bash
   gunicorn --bind 0.0.0.0:5000 main:app
   ```

### Accessing the Application

The application will be available at:
- Local: http://localhost:5000
- Network: http://your-ip-address:5000

## Docker Setup

1. **Build the Docker image**:
   
   ```bash
   docker build -t figma-test-platform .
   ```

2. **Run the container**:
   
   ```bash
   docker run -p 5000:5000 --env-file .env figma-test-platform
   ```

3. **Using Docker Compose**:
   
   Create a `docker-compose.yml` file:
   ```yaml
   version: '3'
   services:
     app:
       build: .
       ports:
         - "5000:5000"
       env_file:
         - .env
       volumes:
         - ./instance:/app/instance
         - ./static/screenshots:/app/static/screenshots
   ```

   Then run:
   ```bash
   docker-compose up
   ```

## Demo Mode

For environments where you can't use API keys or Selenium WebDriver is restricted:

1. Enable demo mode in your `.env` file:
   ```
   DEMO_MODE=true
   ```

2. Start the application as usual:
   ```bash
   python start.py
   ```

All external API calls will be replaced with mock data, and Selenium tests will be simulated.

## Troubleshooting

### Common Issues

1. **Database Connection Errors**:
   - Ensure your database server is running
   - Check the credentials in your connection string
   - Make sure your user has the necessary permissions

2. **API Key Issues**:
   - Verify the API keys are correctly set in your `.env` file
   - Check for any spaces or extra characters when copying keys
   - Ensure you have the appropriate permissions for the APIs

3. **Selenium WebDriver Issues**:
   - Make sure you have the appropriate browser and WebDriver versions installed
   - If running on a server without a display, ensure you're using headless mode (`HEADLESS=true`)
   - Some environments restrict WebDriver; in these cases, use demo mode

4. **Import Errors**:
   - Ensure all dependencies are installed: `pip install -r requirements.txt`
   - Check that your virtual environment is activated

### Getting Help

If you encounter issues not covered here:

1. Check the application logs for more detailed error messages
2. See if your issue is listed in the [GitHub issues](https://github.com/yourusername/figma-test-platform/issues)
3. Create a new issue with detailed information about your problem

## Next Steps

Once the platform is running:

1. Create a new project and provide a Figma file key and web URL to test
2. Analyze the Figma design to extract UI components
3. Generate test cases based on the design
4. Execute the tests and review results
5. Integrate with your CI/CD pipeline using GitHub Actions

Refer to the [User Guide](USER_GUIDE.md) for more detailed usage instructions.