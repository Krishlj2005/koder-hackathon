import os
import re

def load_env_file(env_file='.env'):
    """
    Load environment variables from a .env file
    
    Args:
        env_file: Path to the .env file
    """
    if not os.path.exists(env_file):
        print(f"Warning: {env_file} file not found. Using default environment variables.")
        return
    
    with open(env_file, 'r') as file:
        for line in file:
            line = line.strip()
            # Skip comments and empty lines
            if not line or line.startswith('#'):
                continue
                
            # Match key=value pattern
            match = re.match(r'^([A-Za-z0-9_]+)=(.*)$', line)
            if match:
                key, value = match.groups()
                # Remove quotes if present
                value = value.strip('\'"')
                # Set environment variable
                os.environ[key] = value
                print(f"Set environment variable: {key}")

if __name__ == '__main__':
    # Load environment variables
    load_env_file()
    
    # Print loaded variables (hidden value for security)
    for key in ['FIGMA_ACCESS_TOKEN', 'GEMINI_API_KEY', 'GITHUB_TOKEN', 'DATABASE_URL', 'SESSION_SECRET']:
        if key in os.environ:
            print(f"{key}: {'*' * len(os.environ[key])}")